class InitDefaultCompComment < ActiveRecord::Migration
  def self.up
    corp_screen = Screen.find_by_name('Corporation')
    comment_f = corp_screen.fields.find_by_name('Comments')
    
    corp_screen.rows.each do |r|
      c = r.cell(comment_f.custom_field_id)
      
      current_comment = c.value.to_s.strip
      
      c.value = "#{default_comments}#{current_comment}".strip
      c.save
    end
    
    quo_screen = Screen.find_by_name('Quotation Revision')
    comment_f = quo_screen.fields.find_by_name('Comments')
    bill_to_cf = CustomField.find_by_name('refBillTo')
    
    quo_screen.rows.each do |r|
      c = r.cell(bill_to_cf.id)
      
      current_comment = c.value[comment_f.id.to_s].to_s.strip
      current_comment = "3. #{current_comment}" unless current_comment.empty?
      
      c.value[comment_f.id.to_s] = "#{default_comments}#{current_comment}".strip.gsub(/\r?\n/, "<br />")
      c.save
    end
    
  end

  def self.down
    corp_screen = Screen.find_by_name('Corporation')
    comment_f = corp_screen.fields.find_by_name('Comments')
    
    corp_screen.rows.each do |r|
      c = r.cell(comment_f.custom_field_id)
      
      current_comment = c.value.to_s.strip
      
      c.value = current_comment.gsub(default_comments.strip, '').strip
      c.save
    end
    
    quo_screen = Screen.find_by_name('Quotation Revision')
    comment_f = quo_screen.fields.find_by_name('Comments')
    bill_to_cf = CustomField.find_by_name('refBillTo')
    
    quo_screen.rows.each do |r|
      c = r.cell(bill_to_cf.id)
      
      current_comment = c.value[comment_f.id.to_s].to_s.strip
      
      c.value[comment_f.id.to_s] = current_comment.gsub(default_comments.strip.gsub(/\r?\n/, "<br />"), '').strip
      c.save
    end
    
  end
  
  def self.default_comments
    <<STR
1. Delivery Date: @(delivery_date)
2. Term of Payment: @(term_of_payment)
STR
  end
end
