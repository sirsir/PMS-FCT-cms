# call at RAILS_ROOT
# type client\fct\db\script\test_print_project_data_list.rb | ruby script\console fct_development --debugger
begin
  ApplicationController.enter_admin_mode

  report_templates = ReportTemplates::ProjectDataList.find(:all)
  report_template = report_templates.first
  screen = report_template.screen
  row = screen.rows.last

  result = report_template.generate(row.description, :row => row)

  if File.exists?(result[:filename])
    `cmd /C #{result[:filename]}`
  else
    puts "Unable to generate file '#{result[:filename]}'"
  end
end
