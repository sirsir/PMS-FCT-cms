require 'report_template'

module ReportTemplates
  class DeliverySheet < ReportTemplate
    def draw(options = {})
      revision_row = options[:row]
      color_table = "ff66cc"
      x = 20
      min_font = 6
      pdf.font_size 8
      cal_sub_total = 0.0
      show_price = (revision_row.header_row.value_by_field('Show Price') == "Show")

      #~ Fields
      detail_field_names = [
        'Description',
        'Include',
        'Qty',
        'Unit',
        'Unit Price',
        'Amount',
        'More Detail'
      ]
      if show_price
      vat = number_with_precision(Field.value_by_field_name('Vat', revision_row).delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
      grand_total = number_with_precision(Field.value_by_field_name('Grand Total', revision_row).delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
      end
      get_field_value(revision_row)
      get_ref_info(revision_row)
     
      #~ repeat all page
      pdf.repeat(:all) do
        #~ Page Header
        page_header(x, pdf.cursor)
        #~ Page Footer
        page_footer(x, color_table, min_font, revision_row, show_price)
      end

      #~ report header
      #~ customer_contact
      customer_contact(x, min_font)
      #~ delivery detail
      delivery_detail(min_font)

      #~ Details
      #~ table of first page
      create_table(x, 575, 390, color_table)
      #~ table of next page
      pdf.repeat(lambda { |pg| pg > 1 }) do
        create_table(x, 660, 475, color_table)
      end
      
      #~ data table
      pdf.bounding_box([x,630], :width => 485, :height => 485) do

        subject_in_description= revision_row.header_row.value_by_field('Subject for description').to_s

        if subject_in_description.empty?
          pdf.move_down 85
        else
          pdf.move_down 95
          pdf.text_box subject_in_description, :at => [45, pdf.cursor], :width => 240
          pdf.move_down 15
        end

        item = Hash.new
        no = 1.to_i
        if show_price
          revision_row.detail_rows.each do |r|
            detail_field_names.each { |f_name|
              if f_name == 'Unit Price' || f_name == 'Amount'
                item[f_name.to_s] = number_with_precision(Field.value_by_field_name(f_name, r).delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
              else
                item[f_name.to_s] = Field.value_by_field_name(f_name, r)
              end
            }
            cal_sub_total = data_table(no, item, pdf.cursor, cal_sub_total, show_price)
            no = no + 1
          end
        else
          revision_row.detail_rows.each do |r|
            detail_field_names.each { |f_name|
              if f_name != 'Unit Price' && f_name != 'Amount'    
                item[f_name.to_s] = Field.value_by_field_name(f_name, r)
              end
            }
            cal_sub_total = data_table(no, item, pdf.cursor, cal_sub_total, show_price)
            no = no + 1
          end
        end
      end
      
      #~ Sub Total, Vat and Grand Total, last page
      if show_price
        pdf.text_box number_with_precision(cal_sub_total, number_options), :align => :right, :at => [422,175], :width => 80
        if @field_value[:currency_id] == "THB"
          pdf.text_box @field_value[:currency_id], :at => [402,156], :width => 19
          pdf.text_box vat, :align => :right, :at => [422,156], :width => 80
        end
        pdf.text_box @field_value[:currency_id], :at => [402,138], :width => 19, :style => :bold
        pdf.text_box grand_total, :align => :right, :style => :bold, :at => [422,138], :width => 80
      end
      #~ page number
      page_number

    end

    private

    def get_field_value(revision_row)
      @field_value = {
        :delivery_code => "",
        :date => "",
        :date_footer => "",
        :currency_id => "",
        :delivery_place => "",
        :credit => "",
        :duedate => "",
        :project_code => "",
        :your_ref => "",
        :vat_rate => ""
      }
      
      @field_value[:delivery_code] << revision_row.header_row.value_by_field('Delivery Code')
      
      # Generate the Delivery Code if not gen
      if @field_value[:delivery_code].empty?
        row = revision_row.header_row

        # Get the Project code from the current revision row
        project_row = get_ref_row(revision_row, 'Project Code')
        project_type_cf = CustomField.find_by_name('refProjectType')
        project_type_cell_value = project_row.cell(project_type_cf.id).value

        project_type_cell = Cell.create(:row_id => row.id, :field_id => project_type_cf.id, :value => project_type_cell_value)
        row.load_cell_hash(project_type_cell)

        # Run a Delivery Code
        delivery_code_f = row.screen.fields.find_by_name('Delivery Code')
        delivery_code_cf = delivery_code_f.custom_field
        delivery_code_cell = row.cell(delivery_code_cf.id)
        if delivery_code_cell
          delivery_code_cell.value = {:date => Date.today}
        else
          delivery_code_cell = Cell.create(:row_id => row.id, :field_id => delivery_code_cf.id, :value => {:date => Date.today})
          row.load_cell_hash(delivery_code_cell)
        end

        @field_value[:delivery_code] = CustomFields::AutoNumbering.increase(delivery_code_cf.id, row.cells)
        CustomFields::AutoNumbering.set_cell_text(delivery_code_cell.value, @field_value[:delivery_code])
        delivery_code_cell.save
      end
      date = Date.from_dmy(Field.value_by_field_name('Date', revision_row))
      if date != Date.null_date
        @field_value[:date] << date.strftime('%B %-d, %Y')
        @field_value[:date_footer] << date.strftime('%-d/%b/%Y')
      end

      ref_attendant = get_ref_row revision_row, 'Attendant'
      if ref_attendant
        ref_corporation = get_ref_row ref_attendant, 'Corporation'
      end

      @field_value[:currency_id] << Field.value_by_field_name('Currency', revision_row)
      @field_value[:delivery_place] << Field.value_by_field_name('Delivery Place', revision_row)
      duedate = Date.from_dmy(Field.value_by_field_name('Duedate', revision_row))
      @field_value[:credit] << Field.value_by_field_name('Credit', revision_row)
      @field_value[:duedate] << duedate.strftime('%B %-d, %Y') if duedate != Date.null_date
      @field_value[:project_code] << Field.value_by_field_name('Project Code', revision_row) + "-" + Field.value_by_field_name('Id', ref_corporation)
      @field_value[:your_ref] << Field.value_by_field_name('Your Ref.', revision_row)
      @field_value[:vat_rate] << Field.value_by_field_name('Vat Rate', revision_row)
    end
    
    def get_ref_info(revision_row)
      #~ Get the contact row
      contact_row = get_ref_row(revision_row, 'Attendant')

      if contact_row
        #~ Get the contact person's information
        @contact_info = {
          :title => "",
          :name => "",
          :surname => ""
        }
        @contact_info[:title] << Field.value_by_field_name('Title', contact_row)
        @contact_info[:name] << Field.value_by_field_name('Name', contact_row)
        @contact_info[:surname] << Field.value_by_field_name('Surname', contact_row)
        #~ Get the Corporation row
        corporation_row = get_ref_row(contact_row, 'Corporation')
      end

      if corporation_row
        #~ Get the corporation's information
        @corporation_info = {
          :name => "",
          :phone => "",
          :fax => "",
          :address => ""
        }
        @corporation_info[:name] << Field.value_by_field_name('Name', corporation_row)
        @corporation_info[:phone] << Field.value_by_field_name('Phone', corporation_row)
        @corporation_info[:fax] << Field.value_by_field_name('Fax', corporation_row)
        @corporation_info[:address] << Field.value_by_field_name('Address', corporation_row).gsub('<br />', "\n")
      end

    end

    def get_ref_row(row, field_name)
      field = row.screen.fields.select {|f| f.name == field_name }.first
      actual_row = Field.row_by_field(field, row)
      cell = actual_row.cell(field.custom_field_id) unless actual_row.nil?
      cell.absolute_value[:row] if cell
    end

    def create_table(x, detail_y, detail_height, color_table)
      width_table = 485
      v1 = 40
      v2 = 245
      v3 = 320
      v4 = 380
      w1 = v1
      w2 = v2 - v1
      w3 = v3 - v2
      w4 = v4 - v3
      w5 = width_table - v4
      pdf.save_graphics_state do
        pdf.fill_color color_table
        pdf.fill_and_stroke_rectangle [x,detail_y], width_table, 30
      end
      pdf.bounding_box([x,detail_y], :width => width_table, :height => detail_height) do
        pdf.stroke_bounds
        pdf.stroke do
          pdf.vertical_line 0, detail_height, :at => v1
          pdf.vertical_line 0, detail_height, :at => v2
          pdf.vertical_line 0, detail_height, :at => v3
          pdf.vertical_line 0, detail_height, :at => v4
        end
        pdf.move_down 3
        cy = pdf.cursor
        pdf.text_box "ลำดับ", :at => [0, cy], :width => w1, :align => :center, :style => :bold
        pdf.text_box "รายการ", :at => [v1, cy], :width => w2, :align => :center, :style => :bold
        pdf.text_box "จำนวน", :at => [v2, cy], :width => w3, :align => :center, :style => :bold
        pdf.text_box "ราคาหน่วยละ", :at => [v3, cy], :width => w4, :align => :center, :style => :bold
        pdf.text_box "รวมเป็นเงิน", :at => [v4, cy], :width => w5, :align => :center, :style => :bold
        pdf.move_down 15
        cy = pdf.cursor
        pdf.text_box "No.", :at => [0, cy], :width => w1, :align => :center, :style => :bold
        pdf.text_box "Description", :at => [v1, cy], :width => w2, :align => :center, :style => :bold
        pdf.text_box "Q'ty", :at => [v2, cy], :width => w3, :align => :center, :style => :bold
        pdf.text_box "Unit Price", :at => [v3, cy], :width => w4, :align => :center, :style => :bold
        pdf.text_box "Amount", :at => [v4, cy], :width => w5, :align => :center, :style => :bold
      end
    end
    
    def print_descr(x, y, description)
      pdf.bounding_box([x, y], :width => 201) do
        pdf.text(description, :leading => 5)
      end
      return pdf.cursor
    end

    #~ new page
    def new_page(cal_sub_total, show_price)
      if show_price
        pdf.text_box number_with_precision(cal_sub_total, number_options), :align => :right, :at => [402,30], :width => 80
      end
      cal_sub_total = 0.0
      pdf.start_new_page
      pdf.move_cursor_to 485
      return pdf.cursor, cal_sub_total
    end

    def page_header(x, y)
      w_image = 340
      x_report_name = x + w_image + 15
      y_report_name = 750
      y_no = 685
      pdf.image "#{RAILS_ROOT}/client/fct/app/models/report_templates/images/logo_address.png", :width => w_image, :height => 85, :at => [x, y]
      pdf.bounding_box([x_report_name, y_report_name], :width => 300) do
        pdf.text "Delivery", :size => 25, :style => :bold
        pdf.text "Sheet", :size => 25, :style => :bold
      end
      pdf.text_box "No. :", :at =>[335, y_no],:style => :bold, :width => 70, :align => :right
      pdf.text_box @field_value[:delivery_code], :at =>[410, y_no], :width => 95, :height => 20, :style => :bold, :align => :right
    end

    def customer_contact (x, min_font)
      x_contact = x
      y_contact = 680
      w_contact = 320
      h_contact = 70
      pdf.bounding_box([x_contact,y_contact], :width => w_contact, :height =>  h_contact) do
        x_header = 5
        x_data = 55
        w_data = w_contact - 60
        y_attn = h_contact - 5
        h_copor_name = 10
        y_copor_add = y_attn - 20 - h_copor_name
        h_copor_add = 25
        y_tel_fex = y_copor_add - h_copor_add
        h_tel_fex = 10
        w_tel_fex = w_data/2
        pdf.stroke do
          pdf.rounded_rectangle [0,  h_contact], w_contact,  h_contact, 10
        end
        #~header
        pdf.text_box "Attn.", :at => [x_header, y_attn]
        pdf.text_box "ที่อยู่", :at => [x_header, y_attn - 15]
        pdf.text_box "Address", :at => [x_header, y_attn - 28]
        #~ data
        pdf.text_box @contact_info[:title] +" "+ @contact_info[:name] +" "+ @contact_info[:surname], :style => :bold, :at => [x_data,y_attn], :height => 10, :width => w_data
        pdf.text_box @corporation_info[:name], :at => [x_data, y_attn - 20], :height =>h_copor_name, :overflow => :shrink_to_fit, :style => :bold, :min_font_size => min_font, :width => w_data
        pdf.text_box @corporation_info[:address], :at => [x_data, y_copor_add], :height => h_copor_add, :overflow => :shrink_to_fit, :style => :bold, :min_font_size => min_font, :width => w_data
        pdf.text_box "Tel. : " + @corporation_info[:phone], :at =>[x_data, y_tel_fex], :width => w_tel_fex, :height => h_tel_fex, :style => :bold
        pdf.text_box "Fax : " + @corporation_info[:fax], :at =>[x_data + w_tel_fex, y_tel_fex], :width => w_tel_fex, :height => h_tel_fex, :style => :bold
      end
    end

    def delivery_detail(min_font)
      y_po_detail = 665
      h_po_detail = 60
      pdf.bounding_box([335,y_po_detail], :width => 70, :height => h_po_detail) do
        pdf.text_box "Date :",:at => [0,h_po_detail], :style => :bold, :align => :right
        pdf.text_box "Credit :",:at => [0,h_po_detail - 20], :style => :bold, :align => :right
        pdf.text_box "Duedate :",:at => [0,h_po_detail - 40], :style => :bold, :align => :right
      end
      pdf.bounding_box([410,y_po_detail], :width => 95, :height => h_po_detail) do
        pdf.text_box @field_value[:date],:at => [0,h_po_detail], :align => :right
        pdf.text_box @field_value[:credit],:at => [0,h_po_detail - 20], :align => :right
        pdf.text_box @field_value[:duedate],:at => [0,h_po_detail - 40], :align => :right
      end
      pdf.move_down 5
      y_po_detail = pdf.cursor
      x_proj = 25
      x_yref = 125
      x_vat = 275
      x_curr = 425
      pdf.text_box "Proj. Code :", :at => [x_proj,y_po_detail], :style => :bold
      pdf.text_box "Your Ref :", :at => [x_yref,y_po_detail], :style => :bold
      pdf.text_box "VAT Rate", :at => [x_vat,y_po_detail], :style => :bold
      pdf.text_box "Currency ID", :at => [x_curr,y_po_detail], :style => :bold
      pdf.move_down 13
      y_po_detail = pdf.cursor
      pdf.text_box @field_value[:project_code], :at => [x_proj,y_po_detail]
      pdf.text_box @field_value[:your_ref], :at => [x_yref,y_po_detail], :width => 125, :height => 10, :overflow => :shrink_to_fit, :min_font_size => min_font
      pdf.text_box @field_value[:vat_rate] + " %", :at => [x_vat,y_po_detail], :width => 50, :align => :center
      pdf.text_box @field_value[:currency_id], :at => [x_curr,y_po_detail], :width => 50, :align => :center
    end

    def data_table(no, item, cursor, cal_sub_total, show_price)
      x_no = 0
      x_desc = 42
      x_qty = 247
      x_unit = 298
      x_price = 322
      x_amo = 382
      cursor, cal_sub_total = new_page(cal_sub_total, show_price) if cursor.to_i < 70
      pdf.move_cursor_to cursor - 10
      coor_y = pdf.cursor
      pdf.text_box no.to_s, :at => [x_no, coor_y], :width => 40, :align => :center
      pdf.text_box item['Qty'], :at => [x_qty, coor_y],:width => 48, :align => :right
      pdf.text_box unit_pluralize(item['Qty'],item['Unit']), :at => [x_unit, coor_y],:width => 20, :height => 20, :overflow => :shrink_to_fit
      if show_price
        pdf.text_box item['Unit Price'], :at => [x_price, coor_y],:width => 56, :align => :right
        pdf.text_box item['Amount'], :at => [x_amo, coor_y],:width => 101, :align => :right
        cal_sub_total += item['Amount'].gsub(",","").to_f
      end
      pdf.move_cursor_to print_descr(x_desc, coor_y, item['Description'])
      unless item['More Detail'].empty?
        m_detail = item['More Detail'].gsub('<br />', "\n")
        m_detail.each_line{|m|
        roll = pdf.transaction do
          pdf.move_cursor_to print_descr(x_desc, pdf.cursor, m)
          pdf.rollback if pdf.cursor.to_i < 70
        end
        if roll == false
          co_y, cal_sub_total = new_page(cal_sub_total, show_price)
          pdf.move_cursor_to co_y - 10
          pdf.move_cursor_to print_descr(x_desc, pdf.cursor, m)
        end
        }
      end
      unless item['Include'].empty?
        co_y = pdf.cursor
         if co_y.to_i < 70
            co_y, cal_sub_total = new_page(cal_sub_total, show_price)
            co_y = pdf.cursor-10
          end
        pdf.text_box "Include", :at => [x_desc,co_y], :style => :bold
        pdf.move_down 12
        include = item['Include'].gsub('<br />', "\n")
        include.each_line{|i|
          co_y = pdf.cursor
          if co_y.to_i < 70
            co_y, cal_sub_total = new_page(cal_sub_total, show_price)
            co_y = pdf.cursor-10
          end
          parti = i.partition(" ")
          if parti[0].empty? || parti[2].empty?
            pdf.move_cursor_to print_descr(x_desc, co_y, i)
          else
            pdf.text_box no.to_s + "." + parti[0], :at => [x_no, co_y], :width => 38, :align => :right
            qty_unit = parti[2].split.last(3)
            if (qty_unit[2].nil? || qty_unit[1].nil? || qty_unit[0].nil?)
              pdf.move_cursor_to print_descr(x_desc, co_y, parti[2])
            else
              descr = parti[2].gsub(" "+ qty_unit[1] +" "+ qty_unit[2], "")
              pdf.text_box qty_unit[1], :at => [x_qty, co_y],:width => 48, :align => :right
              pdf.text_box unit_pluralize(qty_unit[1],qty_unit[2]), :at => [x_unit, co_y],:width => 20, :height => 20, :overflow => :shrink_to_fit
              pdf.move_cursor_to print_descr(x_desc, co_y, descr)
            end
          end
        }
      end
      cal_sub_total
    end
    def get_person(revision_row, field_name)
      #~ Get row
      person_row = get_ref_row(revision_row, field_name)
      #~ Get the information
      if person_row
        person = Field.value_by_field_name('Name', person_row)
        person << " "
        person << Field.value_by_field_name('Surname', person_row)[0]
        person << "."
        person << "\n\n" + @field_value[:date_footer]
      else
        person = ""
        person << "\n\n ......../......../........"
      end
      person
    end

    def table_footer(x, revision_row)
      prepare_by = get_person(revision_row, 'Prepare By')
      authorized_by = get_person(revision_row, 'Authorized By')
      delivery_by = get_person(revision_row, 'Delivery By')
      received_by = get_person(revision_row, 'Received By')
      pdf.bounding_box([x,115], :width => 485, :height => 55) do
        pdf.stroke_bounds
        pdf.move_down 15
        pdf.horizontal_rule
        v1 = 122
        v2 = 245
        v3 = 365
        w1 = v1
        w2 = v2 - v1
        w3 = v3 - v2
        w4 = 485 - v3
        pdf.stroke do
          pdf.vertical_line 0, 55, :at => v1
          pdf.vertical_line 0, 55, :at => v2
          pdf.vertical_line 0, 55, :at => v3
        end
        y_hearder = 50
        y_detail = 30
        pdf.text_box "Prepare By", :at => [0, y_hearder], :width => w1, :align => :center
        pdf.text_box "Authorized By", :at => [v1, y_hearder], :width => w2, :align => :center
        pdf.text_box "Delivery By", :at => [v2, y_hearder], :width => w3, :align => :center
        pdf.text_box "Received By", :at => [v3, y_hearder], :width => w4, :align => :center
        pdf.text_box prepare_by, :at => [0, y_detail], :width => w1, :align => :center
        pdf.text_box authorized_by, :at => [v1, y_detail], :width => w2, :align => :center
        pdf.text_box delivery_by, :at => [v2, y_detail], :width => w3, :align => :center
        pdf.text_box received_by, :at => [v3, y_detail], :width => w4, :align => :center
      end
    end

    def page_footer(x, color_table, min_font, revision_row, show_price)
      pdf.text_box "Delivery Place :", :at => [x, 175]
      if @field_value[:delivery_place].empty?
        pdf.text_box @corporation_info[:name], :at => [x, 163], :width => 230, :height => 30, :overflow => :shrink_to_fit, :min_font_size => min_font, :style => :bold
        pdf.text_box "ADDRESS AS ABOVE", :at => [60, 135]
      else
        pdf.text_box @field_value[:delivery_place], :at => [x, 163], :width => 230, :height => 40, :overflow => :shrink_to_fit, :min_font_size => min_font
      end
      pdf.stroke do
        pdf.line [x,182], [505,182]
        pdf.save_graphics_state do
          pdf.fill_color color_table
          pdf.fill_and_stroke_rectangle [265, 182], 135, 57
        end
        pdf.line [505,125], [505,182]
        pdf.line [400,125], [505,125]
      end
      pdf.bounding_box([265,182], :width => 135, :height => 57) do
        pdf.text_box "รวม", :at => [42,54]
        pdf.text_box "/ Sub Total", :at => [56,50]
        pdf.text_box "ภาษีมูลค่าเพิ่ม" , :at => [33,35]
        pdf.text_box "/ Vat 7 %", :at => [73,31]
        pdf.text_box "จำนวนเงินรวมทั้งสิ้น", :at => [17,18], :style => :bold
        pdf.text_box "/ Grand Total", :at => [77,14], :style => :bold
      end
      if show_price
        pdf.text_box @field_value[:currency_id], :at => [402,175], :width => 19
      end
      table_footer(x, revision_row)
    end

    def page_number
      str_page = "P.<page> of <total>"
      options = { :at => [450,713],
        :width => 50,
        :style => :bold,
        :align => :left,
        :page_filter => :all,
        :start_count_at => 1}
      pdf.number_pages str_page, options
    end

    def unit_pluralize(qty, unit)
      if qty.to_f != 1
        unit, d = unit.gsub(/(\.)$/, '|\1').split('|')
        "#{unit.to_s.pluralize}#{d}"
      else
        unit.to_s
      end
    end

  end
end
