require 'report_template'

module ReportTemplates
  class PurchaseBalance < ReportTemplate
    def doc_options
      {
        :top_margin => (line_height*2)+50,
        :bottom_margin => (line_height*1)+50
      }
    end

    def draw(options = {})
      @po_row_ids = options[:row]

      set_reference_rows

      pdf.font_size(7)

      balance_details

      header
      default_footer
    end

    private

    def line_height
      15
    end

    def set_reference_rows
      @rows = {
        :po => []
      }

      @rows[:po] = Row.find(@po_row_ids)
    end

    def header
      x, y = pdf.bounds.top_left

      mark_0 = x
      y += doc_options[:top_margin] - 50

      pdf.repeat(:all) do
        #~ Title
        pdf.text_box "PURCHASE BALANCE", :style => :bold,        :at => [mark_0, y]

        #~ Table Group Header
        x = mark_0
        y -= line_height
        header_groups = balance_data(:header_groups)

        header_groups.each{|h|
          unless h[:content].empty?
            pdf.bounding_box [x, y], :width => h[:column_width], :height => line_height do
              org_fill_color = pdf.fill_color
              pdf.fill_color(default_header_background_color)
              pdf.fill_rectangle pdf.bounds.top_left, pdf.bounds.width, pdf.bounds.height
              pdf.fill_color(org_fill_color)
              
              pdf.stroke_bounds
              pdf.text_box h[:content], :style => :bold, :align => h[:align], :valign => :center,
                :width => h[:column_width]
            end
          end
          x += h[:column_width]
        }
      end
    end

    def balance_details
      data = []
      data << balance_data(:headers)
      data += balance_data(:datas)
      pdf.table(data,
        :header => true,
        :column_widths => balance_data(:column_widths),
        :cell_style => { :padding => 2 }
      ) do |t|
        t.row(0).background_color = default_header_background_color
      end
    end

    def balance_data(item)
      @balance_data ||= begin
        settings = [
          { :group => '',         :header => 'Item No.',        :align => :center, :column_width => 30 },
          { :group => 'P/O',      :header => 'Issue Date',      :align => :center, :column_width => 45 },
          { :group => 'P/O',      :header => 'No. (F.C.TECHNO)',:align => :center, :column_width => 60 },
          { :group => 'P/O',      :header => 'Project Code',    :align => :center, :column_width => 65 },
          { :group => 'P/O',      :header => 'Currency',        :align => :center, :column_width => 40 },
          { :group => 'P/O',      :header => 'Amount',          :align => :right , :column_width => 60, :number_option => number_options },
          { :group => 'P/O',      :header => 'Balance',         :align => :right , :column_width => 60, :number_option => number_options },
          { :group => 'Invoice',  :header => 'Date',            :align => :center, :column_width => 45 },
          { :group => 'Invoice',  :header => 'No.',             :align => :center, :column_width => 60 },
          { :group => 'Invoice',  :header => 'Amount',          :align => :right , :column_width => 60, :number_option => number_options }
        ]

        datas = balance_detail_datas(settings)

        header_groups = []
        settings.each do |s|
          header_group = header_groups.select{|hg| hg[:content] == s[:group] }.first
          if header_group
            header_group[:column_width] += s[:column_width]
          else
            header_groups << {:content => s[:group], :align => :center, :column_width => s[:column_width]}
          end
        end

        {
          :headers => settings.collect{|s| {:content => s[:header], :align => :center} },
          :datas => datas,
          :column_widths => settings.collect{|s| s[:column_width] },
          :header_groups => header_groups
        }
      end

      @balance_data[item]
    end

    def balance_detail_datas(settings)
      aligns = settings.collect{|s| s[:align] }
      number_options = settings.collect{|s| s[:number_option] }
      datas = []
      rows = []
      screen_purchase_invoice =  Screen.find_by_name('Purchase Invoice')
      if screen_purchase_invoice
        screen_id_purchase_invoice = screen_purchase_invoice.id
      else
        screen_id_purchase_invoice = -1
      end

      # Match invoice with po
      @rows[:po].each do |r|
        revision_row = r.latest_revision
        detail_rows = revision_row.detail_rows unless revision_row.nil?
        detail_rows ||= []

        if detail_rows.empty?
          rows << { :purchase_order => r, :purchase_invoice1 => nil, :purchase_invoice2 => nil }
        else
          if detail_rows.select{|dr| dr.screen_id == screen_id_purchase_invoice}.empty?
            no_invoice = 0
            detail_rows.each do |detail_row|
              if detail_row.value_by_field('InvoiceNo_ByItem').empty?
                no_invoice += 1
              else
                rows << { :purchase_order => r, :purchase_invoice1 => detail_row, :purchase_invoice2 => nil }
              end
            end
            if no_invoice == detail_rows.count
              rows << { :purchase_order => r, :purchase_invoice1 => nil, :purchase_invoice2 => nil }
            end
          else
            detail_rows.each do |detail_row|
              if detail_row.screen_id == screen_id_purchase_invoice
                rows << { :purchase_order => r, :purchase_invoice1 => nil, :purchase_invoice2 => detail_row }
              end
            end
          end

        end
        
      end

      rows.each_with_index do |r, idx|
        purchase_order_row = r[:purchase_order]
        purchase_invoice1_row = r[:purchase_invoice1]
        purchase_invoice2_row = r[:purchase_invoice2]

        if purchase_order_row 
          purchase_order_date = purchase_order_row.value_by_field('Issue Date')
          po_no = purchase_order_row.description
          project_code = purchase_order_row.value_by_field('Project Code')
          
          if purchase_order_row.rows.length > 0
            po_amount = validate_value(purchase_order_row.value_by_field('Sub Total')).to_f
          end
          
          currency = purchase_order_row.value_by_field('CurrencyID')
          if purchase_invoice1_row
            invoice_no = purchase_invoice1_row.value_by_field('InvoiceNo_ByItem')
            invoice_date = purchase_invoice1_row.value_by_field('InvoiceDate_ByItem')
            invoice_amount =  validate_value(purchase_invoice1_row.value_by_field('Amount')).to_f
          elsif purchase_invoice2_row
            invoice_no = purchase_invoice2_row.value_by_field('InvoiceNo_DownPayment')
            invoice_date = purchase_invoice2_row.value_by_field('InvoiceDate_DownPayment')
            invoice_amount = validate_value(((purchase_invoice2_row.value_by_field('DownPayment').to_f)/100)*po_amount).to_f
          end
        end
        
        data = []
        data << 0
        data << purchase_order_date.to_s
        data << po_no.to_s
        data << project_code.to_s
        data << currency.to_s
        data << po_amount.to_f
        data << 0
        data << invoice_date.to_s
        data << invoice_no.to_s
        data << invoice_amount.to_s

        data.each_with_index{|d, idx|
          data[idx] = {
            :content => number_options[idx] ? number_with_precision(d, number_options[idx]).to_s : d.to_s,
            :align => aligns[idx]
          }
        }

        datas << data
      end

      datas = datas.sort_by{|d|
        dt1 = Date.from_dmy(d[1][:content])
        dt7 = Date.from_dmy(d[7][:content])
        [
          dt1,
          d[2][:content],
          dt7,
          d[8][:content]
        ]
      }.each_with_index{|d, idx|
        d[0] = {:content => (idx + 1).to_s, :align => aligns[0] }
      }

      po_balance = 0
      last_po_no = ''
      datas.each{|d|
        if last_po_no != d[2][:content]
          last_po_no = d[2][:content]
          po_balance = validate_value(d[5][:content])     # po_amount
        else
          (1..5).each{|i| d[i][:content] = '' }
        end
        po_balance -= validate_value(d[9][:content]).to_f    # invoice_amount
        d[6][:content] = number_with_precision(po_balance, number_options[6])
      }

      datas
    end
  end
end
