require 'report_template'

module ReportTemplates
  class Invoice < ReportTemplate
    attr_accessor :amounts, :font_size, :table_padding, :subtotal, :revision_row

    def doc_options
      {
        :page_size => [648.00, 942.00],
        :left_margin => 0
      }
    end

    def draw(options = {})
      #return
      @font_size = 10
      @table_padding = 2.5
      @subtotal = 0
      @revision_row = options[:row]
      @default_table_start = 510
      @new_table_start = @default_table_start
      @table_end = 340
      @y_subtotal = @table_end - 35
      @y_vat = @table_end-50
      @y_discount = @table_end-10
      @y_grandtotal = @table_end-80
      @x_subject_in_description = 55
      @x_amount = 480
      @x_total = @x_amount + @table_padding
      @x_discount_txt= 100
      @w_total = 115 - (@table_padding * 2)

      pdf.font_size @font_size

      #get and print item details
      items = get_item_info()
      genarate_detail(items,
        :font_size => @font_size,
        :leadding => 5,
        :default_table_start => @default_table_start,
        :table_end => @table_end)

      #get and print header
      header_info = get_header_info()
      invert_print_to_pdf(header_info, :all)

      #get and print footer
      footer_info = get_footer_info()
      invert_print_to_pdf(footer_info, [pdf.page_count])
    end

    def get_header_info
      #get information form database
      ref_customer 		= @revision_row.get_ref_row('Attendant')
      if ref_customer
        ref_corporation = ref_customer.get_ref_row('Corporation')
        branch_no = Field.value_by_field_name('Branch No', ref_corporation)
        customer_name = Field.value_by_field_name('Name', ref_corporation)
        attn = "ATTN: " + Field.value_by_field_name('Name', ref_customer) + " " + Field.value_by_field_name('Surname', ref_customer)

        address = Field.value_by_field_name('Address', ref_corporation).gsub("<br />", "\n")

        tax_id = Field.value_by_field_name('Tax Id', ref_corporation).gsub("<br />", "\n")
        tax_id = "เลขประจำตัวผู้เสียภาษีอากร #{tax_id}" unless tax_id.empty?

        phone = "Tel: #{Field.value_by_field_name('Phone', ref_corporation)}"
        fax = "Fax: #{Field.value_by_field_name('Fax', ref_corporation)}"
        term_of_payment = Field.value_by_field_name('Payment', ref_corporation)
      end

      invoice_number = @revision_row.description.split(" ")[-1]
      po_number = Field.value_by_field_name('P/O Number(Customer)', @revision_row)
      date = Field.value_by_field_name('Date', @revision_row)
      date = Date.from_dmy(date)

      ref_in_charge_person	= @revision_row.get_ref_row('In Charge Person')
      if ref_in_charge_person
        in_charge_person = Field.value_by_field_name('Name', ref_in_charge_person)
        in_charge_person << " "
        in_charge_person << Field.value_by_field_name('Surname', ref_in_charge_person)
      end

      vat_rate = Field.value_by_field_name('Vat Rate', @revision_row)
      start_y = 755
      start_x = 5

      office_type = Field.value_by_field_name('Office Type', @revision_row)

      office_type_text = 'สถานประกอบการ: '
      if office_type=='Head Office'
           office_type_text << "สำนักงานใหญ่ (Head Office)"
      else
           office_type_text << "สาขาที่ #{branch_no}"
      end

      #init property for each information
      data_field = {
        {:at => [start_x+50,  start_y],     :width => 250, :height => 35} => attn,
        {:at => [start_x+50,  start_y-10],  :width => 250, :height => 35} => customer_name,
        {:at => [start_x+50,  start_y-25],  :width => 250, :height => 65, :overflow => :shrink_to_fit} => address,
        {:at => [start_x+50,  start_y-90],  :width => 250, :height => 65, :overflow => :shrink_to_fit} => tax_id,
        {:at => [start_x+50,  start_y-110],  :width => 250, :height => 65, :overflow => :shrink_to_fit} => office_type_text,
        {:at => [start_x+50,  start_y-75],  :width => 100, :height => 10} => phone,
        {:at => [start_x+150, start_y-75],  :width => 100, :height => 10, :align => :center } => fax,
        {:at => [start_x+475, start_y],     :width => 115, :height => 35, :align => :right } => invoice_number,
        {:at => [start_x+475, start_y-45],  :width => 115, :height => 35, :align => :right } => date.strftime('%B %-d, %Y'),
        {:at => [start_x+430,  start_y-110],  :width => 250, :height => 65, :overflow => :shrink_to_fit} => 'สถานประกอบการ: สำนักงานใหญ่',
        {:at => [start_x+0,   start_y-175], :width => 125, :height => 20, :align => :center } => po_number,
        {:at => [start_x+135, start_y-175], :width => 120, :height => 20, :align => :center } => in_charge_person,
        {:at => [start_x+265, start_y-175], :width => 125, :height => 20, :align => :center } => term_of_payment,
        {:at => [start_x+400, start_y-175], :width => 125, :height => 20, :align => :center } => vat_rate
      }

      data_field
    end

    def get_item_info
      @amounts = Array.new
      tp_x2 = (@table_padding * 2)
      align_left = {:align => :left, :overflow => :truncate}
      align_right = {:align => :right, :overflow => :shrink_to_fit}
      align_center = {:align => :center, :overflow => :shrink_to_fit}
      down_payment = @revision_row.value_by_field('DownPayment').to_f
      start_x = @table_padding+5
      start_y = 0
      #~ initial data field for get information form database
      include_meta_data = {
        'No.'         => {:at => [0 + start_x, start_y],   :width => 35 - tp_x2 }.merge(align_right),
        'Description' => {:at => [45 + start_x, start_y], :width => 240 - tp_x2 }.merge(align_left),
        'Qty'         => {:at => [280 + start_x, start_y], :width => 65 - tp_x2 }.merge(align_right),
        'Unit'        => {:at => [345 + start_x, start_y], :width => 25 - tp_x2 }.merge(align_right)
      }
      more_detail = {'Description' => {:at => [45 + start_x, start_y], :width => 175 - (@table_padding * 2), :align => :left, :overflow => :truncate}}
      data_fields = {
        'No.'         => {:at =>  [0 + start_x, start_y], :width => 35 - tp_x2 }.merge(align_center),
        'Description' => {:at => [45 + start_x, start_y],  :width => 240 - tp_x2 }.merge(align_left),
        'Unit Price' 	=> {:at => [370 + start_x, start_y], :width => 110 - tp_x2 }.merge(align_right),
        'Qty'         => {:at => [280 + start_x, start_y], :width => 65 - tp_x2 }.merge(align_right),
        'Unit'        => {:at => [345 + start_x, start_y], :width => 25 - tp_x2 }.merge(align_right),
        'Amount'      => {:at => [@x_amount + start_x, start_y], :width => @w_total }.merge(align_right),
        'Include'   	=> include_meta_data,
        'More Detail' => more_detail
      }



      #~ get information and set property for each information
      item_index = 0
      items = @revision_row.detail_rows.map do |r|
        item = {}
        data_fields.each{|f_name, key|
          val = ""

          case f_name
          when 'Include'
            unless Field.value_by_field_name(f_name, r).empty?
              rows = Field.value_by_field_name('Include', r).gsub("<br />", "\n").split("\n")
              include = rows.map do |row|
                col = row.split(' ')
                {
                  include_meta_data['No.'] => "#{item_index+1}.#{col[0]}",
                  include_meta_data['Description'] => col[1..-3].join(" "),
                  include_meta_data['Qty' ] => col[-2],
                  include_meta_data['Unit' ] => col[-1]
                }
              end
              val = include
              key = f_name
            end
          when 'No.'
            val = item_index+1
          when 'Unit Price'
            u_p = (Field.value_by_field_name(f_name, r).delete(',').to_f)*((down_payment/100).to_f)
            val = number_with_precision(u_p, :precision => 2, :separator => '.', :delimiter => ',')
          when 'More Detail'
            next if Field.value_by_field_name(f_name, r) == ""
            rows = Field.value_by_field_name('More Detail', r).gsub("<br />", "\n").split("\n")
            detail = rows.map do |row|
              {more_detail['Description'] => row}
            end
            val = detail
            key = f_name
          when 'Amount'
            amount_value = (Field.value_by_field_name(f_name, r).delete(',').to_f)*((down_payment/100).to_f)
						amounts[item_index] = amount_value
            val = number_with_precision(amount_value, :precision => 2, :separator => '.', :delimiter => ',')
          else
            val = Field.value_by_field_name(f_name, r)           
          end

          item[key] = val
        }
        item_index +=1

        item
      end

      down_payment_type = @revision_row.value_by_field('DownPaymentType').strip
      #down_payment = @revision_row.value_by_field('DownPayment').to_f

      case down_payment_type
      when 'Down Payment'
        down_payment_txt = "Down Payment"
      when 'Final Payment'
        down_payment_txt = "Less Down Payment"
      end
      
      items << { data_fields['Description'] => "#{down_payment_txt} #{down_payment.to_s}" } if down_payment_txt
      
      items
    end

    def get_footer_info()
      vat = number_with_precision(@revision_row.value_by_field('Vat').delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
      grand_total = number_with_precision(@revision_row.value_by_field('Grand Total').delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
      discount = "-#{number_with_precision(@revision_row.value_by_field('Discount').delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')}"
      discount_txt = "(Discount)"
      

      discount = "" if discount=="-0.00"
      discount_txt = "" if discount=="-0.00"

      data_field = {
        {:at => [@x_discount_txt, @y_discount], :width => @w_total, :height => 10, :overflow => :shrink_to_fit, :align => :right} => discount_txt ,
        {:at => [@x_total, @y_discount], :width => @w_total, :height => 10, :overflow => :shrink_to_fit, :align => :right} => discount ,
        {:at => [@x_total, @y_vat], :width => @w_total, :height => 10, :overflow => :shrink_to_fit, :align => :right} => vat ,
        {:at => [@x_total, @y_grandtotal], :width => @w_total, :height => 25, :overflow => :shrink_to_fit, :align => :right, :valign => :center} => grand_total
      }

      data_field
    end

    def print_to_pdf(data, repeat_mode)
      pdf.repeat(repeat_mode) do
        data.each do |info, options|
          pdf.text_box info.to_s, options
        end
      end
    end

    def invert_print_to_pdf(hash_option_with_data, repeat_mode)
      pdf.repeat(repeat_mode) do
        hash_option_with_data.each do |options, info|
          pdf.text_box info.to_s, options
        end
      end
    end

    def genarate_detail(items, details)
      defaults = {
        :font_size => @font_size,
        :leadding => 0,
        :default_table_start => @default_table_start,
        :new_table_start => @new_table_start,
        :table_end => @table_end
      }
      details = defaults.merge(details)

      @font_size = details[:font_size]

      itr_cursor = details[:default_table_start]-30

      roll = pdf.transaction do
        subject_in_description = Field.value_by_field_name('Subject for description', revision_row).gsub("<br />", "\n")
        
        unless subject_in_description.nil?
          pdf.text_box subject_in_description, details.merge({:at => [@x_subject_in_description, itr_cursor]})
        end
      end

      item_index = 0

      items.each do |i|
        include_items = nil
        more_details = nil
        if i["Include"] != nil
					include_items = i.delete("Include")
				end
        if i["More Detail"] != nil
          more_details = i.delete("More Detail")
        end
        itr_cursor = new_line(itr_cursor, details)
        @subtotal += amounts[item_index].to_f

				roll = pdf.transaction do
          itr_cursor = print_details(i, :itr_cursor => itr_cursor, :leadding => details[:leadding], :font_size => @font_size)
          pdf.rollback if itr_cursor < (details[:table_end] == nil ? 150 : details[:table_end])
        end
        if roll == false
          @subtotal -= amounts[item_index]
          itr_cursor = new_line(itr_cursor, details)
          @subtotal += amounts[item_index]
          itr_cursor = print_details(i, :itr_cursor => itr_cursor, :leadding => details[:leadding], :font_size => @font_size)
        end
        
        
        if more_details
          more_details.each do |more_detail|
            itr_cursor = new_line(itr_cursor, details)
            roll = pdf.transaction do
              itr_cursor = print_details(more_detail, :itr_cursor => itr_cursor, :leadding =>  details[:leadding], :font_size => @font_size)
              pdf.rollback if itr_cursor < (details[:table_end] == nil ? 150 : details[:table_end])
            end
            if roll == false
              itr_cursor = new_line(itr_cursor, details)
              itr_cursor = print_details(more_detail, :itr_cursor => itr_cursor, :leadding =>  details[:leadding], :font_size => @font_size)
            end
          end
        end

        if include_items
          itr_cursor = new_line(itr_cursor, details)
          pdf.text_box("Include", :at => [50+ @table_padding, itr_cursor], :width => 175 - (@table_padding*2), :height => @font_size+details[:leadding], :font_size => @font_size-1, :style => :bold )
         
          include_items.each do |ii|
            itr_cursor = new_line(itr_cursor, details)
            itr_cursor = print_details(ii, :itr_cursor => itr_cursor, :leadding => details[:leadding], :font_size => @font_size )
          end
        end

        item_index += 1
      end
      @subtotal -= @revision_row.value_by_field('Discount').delete(',').to_f

      print_subtotal
    end

    def print_details(items, setting)
      defaults = {
        :itr_cursor => pdf.cursor,
        :font_size => @font_size,
        :leadding => 1
      }
      setting = defaults.merge(setting)

      itr_cursor = setting[:itr_cursor]
      @font_size = setting[:font_size]

      excess_text_box = {}
      items.each do |options, field|
        next unless options[:at]
        
        options[:at][1] = itr_cursor
        options[:height] = @font_size
        options[:size] = @font_size
        excess_text = pdf.text_box(field.to_s, options)
        puts field.to_s, options.inspect

        unless excess_text.empty?
          options[:at][1] -= (@font_size + setting[:leadding])
          excess_text_box[excess_text] = options
        end
      end

      while !excess_text_box.empty?
        excess_text_box.each do |excess_text, options|
          next_excess_text = pdf.text_box(excess_text, options)
          unless next_excess_text.empty?
            options[:at][1] -= (@font_size + setting[:leadding])

            excess_text_box[next_excess_text] = options
          end
          excess_text_box.delete(excess_text)

          itr_cursor = options[:at][1]
        end
      end

      itr_cursor
    end

    def print_subtotal()
      pdf.text_box number_to_currency(@subtotal, :unit =>""),
        {:at => [@x_total, @y_subtotal], :width => @w_total, :height => @font_size, :align => :right}

      #Subtotal = Accumulated to avoid negative value on last page
      #@subtotal = 0
    end

    def new_line(itr_cursor ,setting)
      defaults = {
        :font_size => @font_size,
        :leadding => 0,
        :new_table_start => @new_table_start,
        :table_end => @table_end
      }
      setting = defaults.merge(setting)

      @font_size = setting[:font_size]

      itr_cursor -= (@font_size + setting[:leadding])

      if itr_cursor < setting[:table_end]
        print_subtotal
        pdf.start_new_page
        itr_cursor = setting[:new_table_start] - 10
      end

      itr_cursor
    end
  end
end
