require 'report_template'
require File.join(File.dirname(__FILE__), 'project_data_list')

module ReportTemplates
  class ProjectDataListExcel < ProjectDataList

    def export(options = {})
      @project_row = options[:row].header_row

      set_reference_rows
      
      @worksheet = @xls.add_worksheet
      @formats = {
        :title  =>  {:size => 12, :bold => 1, :merge => 5, :align => 'left'},
        :label  =>  {:size => 10, :bold => 1, :merge => 1, :bg_color => 1,  :align => 'left'},
        :header =>  {:size => 10, :bold => 1, :merge => 1, :bg_color => 27, :align => 'vcenter'},
        :data   =>  {:size => 10, :color => 'black'}
      }
      @formats.each{|k,v| @formats[k] =  @xls.add_format(v) }

      receipt_details
      expense_details

      columns = [receipt_data(:column_widths).size, expense_data(:column_widths).size].max
      column_widths = (0...columns).to_a.collect{|i| [receipt_data(:column_widths)[i], expense_data(:column_widths)[i]].max/4 }
      column_widths.each_with_index{|w, i| @worksheet.set_column(i, i, w) }

      header
    end

    private

    def line_height
      15
    end
    
    def header
      mark_0 = 0
      mark_1 = 8
      mark_2 = 10
      y = 0

      receipt_row = receipt_data(:datas).size + 8
      expense_row = expense_data(:datas).size + 4 + receipt_row

      corp_cf = CustomFields::Reference.find_by_name('refCorporation_Name')

      #~ Title

      @worksheet.merge_range(y, mark_0, y, mark_2+2, "DATA LIST PROJECT ENGINEERING", @formats[:title])

      #~ Line-1
      y += 1
      @worksheet.write(y, mark_0, "PROJECT CODE : #{@project_row.value_by_field('Code')}-#{@project_row.value_by_field('Corporation ID')}", @formats[:label])
      @worksheet.write(y, mark_1, "PROFIT : ", @formats[:label])
      @worksheet.write(y, mark_1+1, "=J#{receipt_row}-J#{expense_row}", @formats[:data])
      @worksheet.write(y, mark_2, "Exlude vat", @formats[:data])

      #~ Line-2
      y += 1
      @worksheet.write(y, mark_0, "PROJECT NAME : #{@project_row.value_by_field('Name')}", @formats[:label])
      @worksheet.write(y, mark_1, "MARGIN : ", @formats[:label])
      @worksheet.write(y, mark_1+1, "=ROUND(J#{receipt_row}/J#{expense_row},2)", @formats[:data])

      #~ Line-3
      y += 1
      corp_row = @project_row.get_ref_row(corp_cf)
      @worksheet.write(y, mark_0, "CUSTOMER NAME : #{corp_row.value_by_field('Name') if corp_row}", @formats[:label])
      @worksheet.write(y, mark_1, "Issue by : ", @formats[:label])
      @worksheet.write(y, mark_1+1, @project_row.value_by_field('IssueBy'), @formats[:data])
      @worksheet.write(y, mark_2, "Update on : ", @formats[:label])
      @worksheet.write(y, mark_2+1, @project_row.value_by_field('Update On'), @formats[:data])
    end

    def receipt_details
      y = 5
      
      #~ Sub-Title
      @worksheet.write(y, 0, "Receipts", @formats[:label])
      
      #~ Headers
      y += 1
      receipt_data(:headers).each_with_index do |h, i|
        @worksheet.write(y, i, h[:content] , @formats[:header])
      end

      row_a = y + 2
      receipt_data(:datas).each do |data|
        y += 1
        data.each_with_index{|d,i|
          content = i < 8 ? d[:content] : validate_value(d[:content])
          @worksheet.write(y, i, content , @formats[:data])
        }
        @worksheet.write(y, 9, "=VALUE(LEFT(H#{y-1},FIND(\" \",H#{y-1},1)))*I#{y-1}" , @formats[:data])
        vat = validate_value(data[11][:content])/validate_value(data[9][:content])
        vat = 0.0 if vat.nan?
        @worksheet.write(y, 11, "=J#{y-1}*#{vat}" , @formats[:data])
        @worksheet.write(y, 12, "=J#{y-1}+L#{y-1}" , @formats[:data])
      end
      row_b = y + 1
      
      y += 1
      @worksheet.write(y, 8, 'Grand Total' , @formats[:label])
      (9..12).each do |i|
        col = (i+?A).chr
        content = "=SUM(#{col}#{row_a}:#{col}#{row_b})"
        @worksheet.write(y, i, content , @formats[:data])
      end

      validate_value(receipt_data(:grand_total)[9][:content])
    end

    def expense_details
      y = receipt_data(:datas).size + (5+3+1)
      
      #~ Sub-Title
      @worksheet.write(y, 0, "Expenses", @formats[:label])

      #~ Headers
      y += 1
      expense_data(:headers).each_with_index do |h, i|
        @worksheet.write(y, i, h[:content] , @formats[:header])
      end

      row_a = y + 2
      expense_data(:datas).each do |data|
        y += 1
        data.each_with_index{|d,i|
          content = i < 8 ? d[:content] : validate_value(d[:content])
          @worksheet.write(y, i, content , @formats[:data])
        }
      end
      row_b = y + 1

      y += 1
      @worksheet.write(y, 8, 'Grand Total' , @formats[:label])
      (9..12).each do |i|
        col = (i+?A).chr
        content = "=SUM(#{col}#{row_a}:#{col}#{row_b})"
        @worksheet.write(y, i, content , @formats[:data])
      end

      validate_value(receipt_data(:grand_total)[9][:content])
    end
  end
end
