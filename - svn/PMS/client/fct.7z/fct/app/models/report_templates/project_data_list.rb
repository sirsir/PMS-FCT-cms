require 'report_template'

module ReportTemplates
  class ProjectDataList < ReportTemplate
    def doc_options
      {
        :page_size => 'A3',
        :top_margin => (line_height*4)+50
      }
    end

    def draw(options = {})
      @project_row = options[:row].header_row

      set_reference_rows

      pdf.font_size(7)

      sum_receipt = receipt_details
      sum_expense = expense_details

      pdf.font_size(8) do
        header(sum_receipt, sum_expense)
        default_footer
      end
    end

    private

    def line_height
      15
    end

    def set_reference_rows
      @rows = {
        :quo => [],
        :quo_dtls => {},
        :del => [],
        :del_dtls => {},
        :inv => [],
        :inv_dtls => {},
        :po => [],
        :po_dtls => {},
        :po_invs => {}
      }

      reference_rows = @project_row.used_by(true)

      reference_rows.each do |r|
        if r.screen.name =~ /Quotation/i
          group = :quo
          @rows[:quo_dtls][r.id] = r.detail_rows.select{|dr| dr.screen.name == 'Quotation_Detail' }
        elsif r.screen.name =~ /Delivery/i
          group = :del
          @rows[:del_dtls][r.id] = r.detail_rows.select{|dr| dr.screen.name == 'Delivery Detail' }
        elsif r.screen.name =~ /Invoice/i
          group = :inv
          inv_rev = r.revision_rows.select{|dr| dr.screen.name == 'Invoice Revision' }.first
          @rows[:inv_dtls][r.id] = inv_rev.detail_rows.select{|dr| dr.screen.name == 'Invoice Detail' }
        elsif r.screen.name =~ /Purchase Order/i
          group = :po
          @rows[:po_dtls][r.id] = r.detail_rows.select{|dr| dr.screen.name == 'Purchase Order Details' }
          @rows[:po_invs][r.id] = r.detail_rows.select{|dr| dr.screen.name == 'Purchase Invoice' }
        end

        case r
        when RevisionRow
          row = r.header_row.latest_revision
        else
          row = r
        end
        
        @rows[group] << row
      end

      @rows[:quo].uniq!
      @rows[:del].uniq!
      @rows[:inv].uniq!
      @rows[:po].uniq!
    end

    def header(sum_receipt, sum_expense)
      x, y = pdf.bounds.top_left

      mark_0 = x 
      mark_1 = 500
      mark_2 = 600
      y += doc_options[:top_margin] - 50

      corp_cf = CustomFields::Reference.find_by_name('refCorporation_Name')

      pdf.repeat(:all) do
        #~ Title
        pdf.text_box "DATA LIST PROJECT ENGINEERING", :style => :bold,        :at => [mark_0, y]

        #~ Line-1
        y -= line_height
        profit = number_with_precision(sum_receipt - sum_expense, number_options)
        pdf.text_box "PROJECT CODE : #{@project_row.value_by_field('Code')}-#{@project_row.value_by_field('Corporation ID')}", :at => [mark_0, y]
        pdf.text_box "PROFIT : #{profit}",                                    :at => [mark_1, y]
        pdf.text_box "Exlude vat",                                            :at => [mark_2, y]

        #~ Line-2
        y -= line_height
        margin = number_with_precision(sum_expense != 0 ? sum_receipt / sum_expense : 0, number_options)
        pdf.text_box "PROJECT NAME : #{@project_row.value_by_field('Name')}", :at => [mark_0, y]
        pdf.text_box "MARGIN : #{margin}",                                    :at => [mark_1, y]

        #~ Line-3
        y -= line_height

        corp_row = @project_row.get_ref_row(corp_cf)
        pdf.text_box "CUSTOMER NAME : #{corp_row.value_by_field('Name') if corp_row}", :at => [mark_0, y]
        pdf.text_box "Issue by : #{@project_row.value_by_field('IssueBy')}",          :at => [mark_1, y]
        pdf.text_box "Update on : #{@project_row.value_by_field('Update On')}",       :at => [mark_2, y]
      end
    end

    def receipt_details
      pdf.stoke_line
      pdf.pad_top(10) { pdf.text 'Receipts', :style => :bold }
      
      data = []
      data << receipt_data(:headers)
      data += receipt_data(:datas)
      data << receipt_data(:grand_total)

      pdf.table(data,
        :header => true,
        :column_widths => receipt_data(:column_widths),
        :cell_style => { :padding => 2 }
      ) do |t|
        t.row(0).background_color = default_header_background_color
      end
      
      validate_value(data.last[9][:content])
    end

    def expense_details
      pdf.pad_top(10) { pdf.text 'Expenses', :style => :bold }

      data = []
      data << expense_data(:headers)
      data += expense_data(:datas)
      data << expense_data(:grand_total)

      pdf.table(data,
        :header => true,
        :column_widths => expense_data(:column_widths),
        :cell_style => { :padding => 2 }
      ) do |t|
        t.row(0).background_color = default_header_background_color
      end

      validate_value(data.last[9][:content])
    end

    def receipt_data(item)
      @receipt_data ||= begin
        settings = [
          { :header => 'ITEM NO.',              :align => :center, :column_width => 25 },
          { :header => 'QUOTATION ISSUE DATE',  :align => :center, :column_width => 45 },
          { :header => 'QUOTATION NO.',         :align => :center, :column_width => 75 },
          { :header => 'P/O NO. (Customer)',    :align => :center, :column_width => 75 },
          { :header => 'INVOICE NO.',           :align => :center, :column_width => 75 },
          { :header => 'INVOICE DATE',          :align => :center, :column_width => 45 },
          { :header => 'DESCRIPTION',           :align => :left  , :column_width => 170 },
          { :header => 'Qty',                   :align => :right , :column_width => 30 }, #:number_option => number_options },
          { :header => 'Unit Price',            :align => :right , :column_width => 45, :number_option => number_options },
          { :header => 'Receipt Baht',          :align => :right , :column_width => 45, :number_option => number_options },
          { :header => 'Receipt Yen',           :align => :right , :column_width => 45, :number_option => number_options },
          { :header => 'VAT 7%',                :align => :right , :column_width => 45, :number_option => number_options },
          { :header => 'AMOUNT (BAHT)',         :align => :right , :column_width => 45, :number_option => number_options }
        ]

        datas = receipt_detail_datas(settings)
        {
          :headers => settings.collect{|s| {:content => s[:header], :align => :center} },
          :datas => datas,
          :column_widths => settings.collect{|s| s[:column_width] },
          :grand_total => accumulate_grand_total(datas)
        }
      end
      
      @receipt_data[item]
    end

    def receipt_detail_datas(settings)
      aligns = settings.collect{|s| s[:align] }
      number_options = settings.collect{|s| s[:number_option] }
      datas = []

      rows = []

      # Match invoice with cpo
      @rows[:inv].each do |r|
        ref_po_row = r.get_ref_row('P/O Number(Customer)')
        quo_row = @rows[:quo].select{|o| o.header_row.id == ref_po_row.id }.first if ref_po_row

        @rows[:inv_dtls][r.id].each do |dr|
          rows << { :quotation => quo_row || ref_po_row, :invoice => dr }
        end
      end
      
      # Add unmatched quotations
      @rows[:quo].each do |r|
        @rows[:quo_dtls][r.id].each do |dr|
          rows << { :quotation => dr, :invoice => nil }
        end unless rows.any?{|x| x[:quotation] && x[:quotation] == r }
      end

      q_no = "0"
      rows.each_with_index do |r, idx|
        quotation_row = r[:quotation]
        invoice_row = r[:invoice]

        descr = (invoice_row || quotation_row).description
        
        if quotation_row
          quotation_date = quotation_row.value_by_field('IssueDate')
          quotation_no = (quotation_row.is_a?(DetailRow) ? quotation_row.revision_row : quotation_row).description

          po_no = quotation_row.value_by_field('C P/O')
          exch_rate = validate_value(quotation_row.value_by_field('ExchRate')).to_f
          vat_rate = validate_value(quotation_row.value_by_field('Vat Rate')).to_f
          currency = quotation_row.value_by_field('CurrencyID')
          unit = quotation_row.value_by_field('Unit')
          qty = validate_value(quotation_row.value_by_field('Qty')).to_f
          unit_price = validate_value(quotation_row.value_by_field('NetPrice')).to_f
          discount = validate_value(quotation_row.value_by_field('Discount')).to_f
        end
        
        if invoice_row
          invoice_no = invoice_row.value_by_field('Invoice No')
          invoice_date = invoice_row.value_by_field('Date')
          exch_rate = validate_value(invoice_row.value_by_field('ExchRate')).to_f
          vat_rate = validate_value(invoice_row.value_by_field('Vat Rate')).to_f
          currency = invoice_row.value_by_field('Currency')
          unit = invoice_row.value_by_field('Unit')
          qty = validate_value(invoice_row.value_by_field('Qty')).to_f
          unit_price = validate_value(invoice_row.value_by_field('Unit Price')).to_f

          down_payment = validate_value(invoice_row.value_by_field('DownPayment')).to_f
          down_payment = down_payment.to_i if down_payment.to_i == down_payment
          down_payment_txt = " (#{down_payment}%)" if down_payment > 0 && down_payment < 100
        end

        if down_payment.to_f > 0 && down_payment.to_f < 100
          unit_price = unit_price.to_f * down_payment.to_f/100
        end

        qty = qty.to_i if qty.to_i == qty

        if currency =~ /THB/
          total_thb = unit_price.to_f * qty.to_f
          total_jpy = nil
        elsif currency =~ /JPY/
          total_jpy = unit_price.to_f * qty.to_f
          total_thb = total_jpy * exch_rate
        end
        
        vat = total_thb.to_f * vat_rate.to_f/100.0
        total_vat = total_thb.to_f + vat.to_f

        data = []
        data << idx
        data << quotation_date
        data << quotation_no
        data << po_no
        data << invoice_no
        data << invoice_date
        data << "#{descr}#{down_payment_txt}"
        data << "#{qty} #{unit_pluralize(qty, unit).rjust(3, ' ')}"
        data << unit_price
        data << total_thb
        data << total_jpy
        data << vat
        data << total_vat
        
        data.each_with_index{|d, idx|
          data[idx] = {
            :content => number_options[idx] ? number_with_precision(d, number_options[idx]).to_s : d.to_s,
            :align => aligns[idx]
          }
        }

        datas << data
        
        if (!invoice_row) && discount.to_f > 0.0
          if q_no != quotation_no.to_s
            q_no = quotation_no.to_s
            if currency =~ /THB/
              total_thb = discount.to_f
              total_jpy = nil
            elsif currency =~ /JPY/
              total_jpy = "-" + discount.to_s
              total_thb = discount.to_f * exch_rate
            end
            vat = total_thb.to_f * vat_rate.to_f/100.0
            total_vat = total_thb.to_f + vat.to_f
            data = []
            data << ""
            data << quotation_date
            data << quotation_no
            data << po_no
            data << invoice_no
            data << invoice_date
            data << "Discount"
            data << "1"
            data << "-" + discount.to_s
            data << "-" + total_thb.to_s
            data << total_jpy
            data << "-" + vat.to_s
            data << "-" + total_vat.to_s

            data.each_with_index{|d, idx|
              data[idx] = {
                :content => number_options[idx] ? number_with_precision(d, number_options[idx]).to_s : d.to_s,
                :align => aligns[idx]
              }
            }

            datas << data
          end          
        end

      end

      datas = datas.sort_by{|d|
        idx = d[0][:content]
        d = d[1..5].collect{|v| sorting_value(v[:content]) }
        d[0] = sorting_value(d[0], :date)
        d[4] = sorting_value(d[4], :date)

        d[0] = d[4] if d[0] == Date.null_date

        d << idx
      }.each_with_index{|d, idx|
        d[0] = {:content => (idx + 1).to_s, :align => aligns[0] }
      }

      datas
    end

    def expense_data(item)
      @expense_data ||= begin
        settings = [
          { :header => 'ITEM NO.',              :align => :center, :column_width => 25 },
          { :header => 'PO ISSUE DATE',         :align => :center, :column_width => 45 },
          { :header => 'P/O NO. (F.C.TECHNO)',  :align => :center, :column_width => 75 },
          { :header => 'MAKER',                 :align => :center, :column_width => 75 },
          { :header => 'INVOICE NO.',           :align => :center, :column_width => 75 },
          { :header => 'INVOICE DATE',          :align => :center, :column_width => 45 },
          { :header => 'DESCRIPTION',           :align => :left  , :column_width => 170 },
          { :header => 'Qty',                   :align => :right , :column_width => 30 }, #:number_option => number_options },
          { :header => 'Unit Price',            :align => :right , :column_width => 45, :number_option => number_options },
          { :header => 'Expense Bath',          :align => :right , :column_width => 45, :number_option => number_options },
          { :header => 'Expense Yen',           :align => :right , :column_width => 45, :number_option => number_options },
          { :header => 'VAT 7%',                :align => :right , :column_width => 45, :number_option => number_options },
          { :header => 'AMOUNT (BATH)',         :align => :right , :column_width => 45, :number_option => number_options }
        ]

        datas = expense_detail_datas(settings)
        {
          :headers => settings.collect{|s| {:content => s[:header], :align => :center} },
          :datas => datas,
          :column_widths => settings.collect{|s| s[:column_width] },
          :grand_total => accumulate_grand_total(datas)
        }
      end

      @expense_data[item]
    end
    
    def accumulate_grand_total(datas)
      grand_total = []
      grand_total[8] = {:content => 'Grand Total', :align => :right}
      (9..12).each do |i|
        grand_total[i] = {:content => 0, :align => :right }
      end
      datas.each do |d|
        (9..12).each do |i|
          grand_total[i][:content] += validate_value(d[i][:content]).to_f
        end
      end

      grand_total[9..12].each{|d| d[:content] = number_with_precision(d[:content], number_options) }

      grand_total
    end

    def expense_detail_datas(settings)
      aligns = settings.collect{|s| s[:align] }
      number_options = settings.collect{|s| s[:number_option] }
      datas = []

      rows = []

      # Add unmatched quotations
      @rows[:po].each do |r|
        if @rows[:po_invs][r.id].nil?
          next r
        end
        @rows[:po_invs][r.id] << nil if @rows[:po_invs][r.id].empty?

        @rows[:po_invs][r.id].each do |pi|
          @rows[:po_dtls][r.id].each do |dr|
            rows << { :purchase_order => dr, :purchase_invoice => pi }
          end unless rows.any?{|x| x[:purchase_order] && x[:purchase_order] == r }
        end
      end

      rows.each_with_index do |r, idx|
        purchase_order_row = r[:purchase_order]
        purchase_invoice_row = r[:purchase_invoice]

        descr = purchase_order_row.description

        if purchase_order_row
          purchase_order_date = purchase_order_row.value_by_field('Issue Date')
          purchase_order_no = (purchase_order_row.is_a?(DetailRow) ? purchase_order_row.revision_row : purchase_order_row).description
          exch_rate = validate_value(purchase_order_row.value_by_field('ExchRate')).to_f
          vat_rate = validate_value(purchase_order_row.value_by_field('Vat Rate')).to_f
          currency = purchase_order_row.value_by_field('CurrencyID')
          corp_row = purchase_order_row.get_ref_row('Corporation Name')
          
          unit = purchase_order_row.value_by_field('Unit')
          qty = validate_value(purchase_order_row.value_by_field('Qty')).to_f
          unit_price = validate_value(purchase_order_row.value_by_field('UnitPrice')).to_f
          invoice_date = purchase_order_row.value_by_field('InvoiceDate_ByItem')
          invoice_no = purchase_order_row.value_by_field('InvoiceNo_ByItem')
          discount = purchase_order_row.value_by_field('Discount')
        end

        if corp_row
          maker = corp_row.value_by_field('Short Name')
        end

        if purchase_invoice_row
          invoice_date = purchase_invoice_row.value_by_field('InvoiceDate_DownPayment')
          invoice_no = purchase_invoice_row.value_by_field('InvoiceNo_DownPayment')

          down_payment = validate_value(purchase_invoice_row.value_by_field('DownPayment')).to_f
          down_payment = down_payment.to_i if down_payment.to_i == down_payment
          down_payment_txt = " (#{down_payment}%)" if down_payment > 0 && down_payment < 100
        end

        if down_payment.to_f > 0 && down_payment.to_f < 100
          unit_price = unit_price.to_f * down_payment.to_f/100
        end

        qty = qty.to_i if qty.to_i == qty

        if currency =~ /THB/
          total_thb = unit_price.to_f * qty.to_f
          total_jpy = nil
        elsif currency =~ /JPY/
          total_jpy = unit_price.to_f * qty.to_f
          total_thb = total_jpy * exch_rate
        end

        vat = total_thb.to_f * vat_rate.to_f/100.0
        total_vat = total_thb.to_f + vat.to_f
        idx_discount = idx
        data = []
        data << idx
        data << purchase_order_date
        data << purchase_order_no
        data << maker
        data << invoice_no
        data << invoice_date
        data << "#{descr}#{down_payment_txt}"
        data << "#{qty} #{unit_pluralize(qty, unit).rjust(3, ' ')}"
        data << unit_price
        data << total_thb
        data << total_jpy
        data << vat
        data << total_vat

        data.each_with_index{|d, idx|
          data[idx] = {
            :content => number_options[idx] ? number_with_precision(d, number_options[idx]).to_s : d.to_s,
            :align => aligns[idx]
          }
        }

        datas << data
        if (!purchase_invoice_row) && (discount.to_f > 0.0)
          if currency =~ /THB/
            total_thb = discount.to_f
            total_jpy = nil
          elsif currency =~ /JPY/
            total_jpy = "-" + discount.to_s
            total_thb = discount.to_f * exch_rate
          end
          vat = total_thb.to_f * vat_rate.to_f/100.0
          total_vat = total_thb.to_f + vat.to_f
          data = []
          data << idx_discount
          data << purchase_order_date
          data << purchase_order_no
          data << maker
          data << invoice_no
          data << invoice_date
          data << "Discount of #{descr}#{down_payment_txt}"
          data << "1"
          data << "-" + discount.to_s
          data << "-" + total_thb.to_s
          data << total_jpy
          data << "-" + vat.to_s
          data << "-" + total_vat.to_s

          data.each_with_index{|d, idx|
            data[idx] = {
              :content => number_options[idx] ? number_with_precision(d, number_options[idx]).to_s : d.to_s,
              :align => aligns[idx]
            }
          }

          datas << data
        end
      end

      datas = datas.sort_by{|d|
        idx = d[0][:content]
        d = d[1..5].collect{|v| sorting_value(v[:content]) }
        d[0] = sorting_value(d[0], :date)
        d[4] = sorting_value(d[4], :date)

        d[0] = d[4] if d[0] == Date.null_date

        d << idx
      }.each_with_index{|d, idx|
        d[0] = {:content => (idx + 1).to_s, :align => aligns[0] }
      }
      
      datas
    end
    
    def sorting_value(value, format = :string)
      case format
      when :string
        value.to_s.strip.empty? ? 255.chr : value
      when :date
        Date.from_dmy(value)
      end
    end
    def unit_pluralize(qty, unit)
      if qty.to_f != 1
        unit, d = unit.gsub(/(\.)$/, '|\1').split('|')
        "#{unit.to_s.pluralize}#{d}"
      else
        unit.to_s
      end
    end
  end
end
