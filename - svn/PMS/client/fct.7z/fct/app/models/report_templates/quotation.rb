require 'report_template'

module ReportTemplates
	class Quotation < ReportTemplate
		attr_accessor :amounts, :font_size, :table_padding, :subtotal, :revision_row
		
		def draw(options = {})
			@font_size = 8
			@table_padding = 1.5
			@subtotal = 0
			@revision_row = options[:row]
			
			pdf.font_size(@font_size)
			#~Generate Page
			items = get_item_info()
			genarate_detail(items, :font_size => @font_size, :leadding => 5, :new_table_start => 560, :default_table_start =>490, :table_end => 300)
			
			#~Print Header info
			items = get_header_info()
			invert_print_to_pdf(items, :all)
			
			#~Print Page Footer information
			items = get_footer_info()
			invert_print_to_pdf(items, :all)
			
			#~Print Revision information
			items = get_revision_info()
			invert_print_to_pdf(items, [1])
			
			#~Print Table footer information
			items = get_detail_footer_info()
			invert_print_to_pdf(items, [pdf.page_count])

			#~Print template
			print_template
		end
		
		def get_ref_row(row, field_name)
			field = row.screen.fields.select {|f| f.name == field_name }.first
			actual_row = Field.row_by_field(field, row)
			cell = actual_row.cell(field.custom_field_id) unless actual_row.nil?
			cell.absolute_value[:row] if cell
		end
		
		def table(name, details)
			x = (details[:x] == nil) ? 0 : details[:x]
			y = (details[:y] == nil) ? 0 : details[:y]
			width = (details[:width] == nil) ? 100 : details[:width]
			height = (details[:height] == nil) ? 100 : details[:height]
			col = (details[:col] == nil || details[:col] == 0) ? 1 : details[:col]
			row = (details[:row] == nil || details[:row] == 0) ? 1 : details[:row]
			cells_width = (details[:cells_width] == nil) ? Array.new(col, width/col) : details[:cells_width]
			cells_height = (details[:cells_height] == nil) ? Array.new(row, height/row) : details[:cells_height]
			fill_color = details[:fill_color]
			
			# draw bounds
			pdf.fill_and_stroke do
				pdf.fill_color fill_color
				pdf.rectangle [x,y], width, height
				
				# vertical line
				itr= x
				cells_width.each do |i|
					itr += i
					pdf.vertical_line y, y-height, :at => itr
				end
				
				#horizontal line
				itr= y
				cells_height.each do |i|
					itr -= i
					pdf.horizontal_line x, x+width, :at => itr
				end
				
			end if details[:fill_color] != nil
			
			pdf.stroke do
				pdf.rectangle [x,y], width, height
				
				# vertical line
				itr= x
				cells_width.each do |i|
					itr += i
					pdf.vertical_line y, y-height, :at => itr
				end
				
				#horizontal line
				itr= y
				cells_height.each do |i|
					itr -= i
					pdf.horizontal_line x, x+width, :at => itr
				end
			end if details[:fill_color] == nil
			pdf.fill_color "000000"
		end
		
		def print_to_pdf(hash_data_with_option, repeat_mode)
			pdf.repeat(repeat_mode) do
				hash_data_with_option.each do |info, options|
					pdf.text_box info, options
				end
			end
		end
		
		def invert_print_to_pdf(hash_option_with_data, repeat_mode)
			pdf.repeat(repeat_mode) do
				hash_option_with_data.each do |options, info|
				    if info.index('IMG:>')==0
						info.gsub!('IMG:>','')
						
						if info !="" 
              if info[-1,1]!="/" and info[-1,1]!="\\" and File.file?(info)
                pdf.stroke do
                  pdf.image info, options
                end
              end
						end
					else
            if options.has_key?(:font_typeface)
              scale_size = 1.8
              font_size = 8
              font_size = options[:font_size].to_f unless options[:font_size].nil?

              options[:font_size] = font_size*scale_size
              
              
              pdf.font(options[:font_typeface]) do
                pdf.text_box info, options
              end
            else
              pdf.text_box info, options
            end
					end
				end
			end
		end
		
		def get_footer_info()
			ref_authorized = get_ref_row @revision_row, 'Authorized Person'
      ref_substituted_by = get_ref_row @revision_row, 'Substituted By'
			ref_person_in_charge = get_ref_row @revision_row, 'In Charge Person'
			authorized = ' '*30
			person_in_charge = ' '*30
			
			if ref_authorized
				authorized =  %Q{#{Field.value_by_field_name('Title', ref_authorized)}#{Field.value_by_field_name('Name', ref_authorized)} #{Field.value_by_field_name('Surname', ref_authorized)}}
				authorized_phone = Field.value_by_field_name('MobilePhone', ref_authorized)=="" ? "" : %Q{(#{Field.value_by_field_name('MobilePhone', ref_authorized)})}

        if ref_substituted_by
          authorized_img = Field.value_by_field_name('SignatureFor', ref_substituted_by)
        else
          authorized_img = Field.value_by_field_name('Signature', ref_authorized)
        end
				
				authorized_img.gsub!(/.*src=\"(.*?)\".*/, '\1')
			end
			
			if ref_person_in_charge
				person_in_charge = %Q{#{Field.value_by_field_name('Title', ref_person_in_charge)}#{Field.value_by_field_name('Name', ref_person_in_charge)} #{Field.value_by_field_name('Surname', ref_person_in_charge)}}
				person_in_charge_img = Field.value_by_field_name('Signature', ref_person_in_charge)
				person_in_charge_img.gsub!(/.*src=\"(.*?)\".*/, '\1')
				person_in_charge_phone = Field.value_by_field_name('MobilePhone', ref_person_in_charge)=="" ? "" : %Q{(#{Field.value_by_field_name('MobilePhone', ref_person_in_charge)})}
			end
			
			notice = "if you have any questions concerning this quotation,\nCould you contact to #{authorized}#{authorized_phone} or #{person_in_charge}#{person_in_charge_phone}"
			data_fields ={{:at => [15, 235], :width => 290, :overflow => :shrink_to_fit, :size => 6, :style => :italic} => notice,
				{:at => [305, 200], :width => 80, :height => 10, :overflow => :shrink_to_fit, :align => :center} => "(#{authorized})",
				{:at => [305, 220], :width => 80, :height => 20, :overflow => :shrink_to_fit, :align => :center} => "IMG:>#{RAILS_ROOT}/public#{authorized_img}",
				#{:at => [305, 220], :width => 80, :height => 20, :overflow => :shrink_to_fit, :align => :center} => "IMG:>#{authorized_img}",
				{:at => [435, 200], :width => 80, :height => 10, :overflow => :shrink_to_fit, :align => :center} => "(#{person_in_charge})",
				#{:at => [430, 210], :width => 100, :height => 20, :overflow => :shrink_to_fit, :align => :center} => "IMG:>#{RAILS_ROOT}#{person_in_charge_img}"
				{:at => [435, 220], :width => 80, :height => 20, :overflow => :shrink_to_fit, :align => :center} => "IMG:>#{RAILS_ROOT}/public#{person_in_charge_img}"
			}
			
			data_fields
		end
		
		def get_detail_footer_info()
			grand_total_currency = number_to_currency(Field.value_by_field_name('GrandTotal', @revision_row), :unit =>"")
			grand_total = number_with_precision(grand_total_currency.delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
			discount = number_to_currency(Field.value_by_field_name('Discount', @revision_row), :unit =>"")
			currency_id = Field.value_by_field_name('CurrencyID', @revision_row)
			x = 435 + @table_padding
			y = 256
			width = 70 - (@table_padding*2)
			data_fields = {	{:at => [x, y], :width => width, :height => @font_size, :align => :right} 	=> grand_total,
				{:at => [x, 269], :width => width, :height => @font_size, :align => :right}=> discount,
				{:at => [x, 269], :width => width, :height => @font_size, :align => :left} 	=> currency_id,
				{:at => [x, y], :width => width, :height => @font_size, :align => :left}	=> currency_id
			}
			
			data_fields
		end
		
		def get_revision_info()
			ref_bill_to = get_ref_row @revision_row, 'BillTo'
			ref_cc = get_ref_row @revision_row, 'CC'
			bill_to = ""
			customer_address = ""
			phone = ""
			fax = ""
			comments = ""
			delivery_date = ""
			term_of_payment = ""
			subject_in_description = Field.value_by_field_name('Subject for description', @revision_row).gsub("<br />", "\n")
			
			if ref_bill_to
				bill_to = %Q{#{Field.value_by_field_name('Title', ref_bill_to)}#{Field.value_by_field_name('Name', ref_bill_to)} #{Field.value_by_field_name('Surname', ref_bill_to)}\n#{Field.value_by_field_name('Position', ref_bill_to)}}
				ref_customer = get_ref_row ref_bill_to, 'Corporation'
				
				if ref_customer
					customer_address = %Q{#{ref_customer.description}\n#{Field.value_by_field_name('Address', ref_customer).gsub("<br />","\n")}}
					phone = "Phone: #{Field.value_by_field_name('Phone', ref_customer)}"
					fax = "Fax: #{Field.value_by_field_name('Fax', ref_customer)}"
					#~ additional_comments = Field.value_by_field_name('Comments', ref_customer).gsub("<br />", "\n")
					delivery_date = Field.value_by_field_name('Delivery Term', ref_customer).gsub("<br />", "\n")
					term_of_payment = Field.value_by_field_name('Payment', ref_customer).gsub("<br />", "\n")
					
					#~ comments = <<STR
					#~ 1. Delivery Date: #{delivery_date}
					#~ 2. Term of Payment: #{term_of_payment}
					#~ #{additional_comments}
					#~ STR
					
					comments =  Field.value_by_field_name('Comments', @revision_row).gsub("<br />", "\n")
					comments.gsub!('@(delivery_date)', delivery_date)
					comments.gsub!('@(term_of_payment)', term_of_payment)
				end
			end

      comments.gsub!(/^ /m, Prawn::Text::NBSP)

			cc = "customer contact"
			if ref_cc
				cc = %Q{#{Field.value_by_field_name('Title', ref_cc)}#{Field.value_by_field_name('Name', ref_cc)} #{Field.value_by_field_name('Surname', ref_cc)}\n#{Field.value_by_field_name('Position', ref_cc)}}
			else
				cc = ''
			end

			data_fields = {	{:at =>[50, 670], :width => 99, :height => 20, :overflow => :shrink_to_fit } => bill_to,
				{:at =>[185, 670], :width => 99, :height => 20, :overflow => :shrink_to_fit } => cc,
				{:at =>[15, 650], :width => 250, :height => 35, :overflow => :shrink_to_fit, :leading => 2 } => customer_address,
				{:at =>[15, 610], :width => 85, :height => 10, :overflow => :shrink_to_fit} => phone,
				{:at =>[100, 610], :width => 85, :height => 10, :overflow => :shrink_to_fit} => fax,
				{:at =>[45, 590], :width => 470, :overflow => :shrink_to_fit, :font_typeface => "Courier", :kerning =>false, :height => 50} => comments,
				{:at =>[55, 490], :width => 215, :height => 30, :overflow => :shrink_to_fit, :size => 8 } => subject_in_description.strip
			}
			
			data_fields
		end

		def get_header_info()
			ref_bill_to = get_ref_row @revision_row, 'BillTo'
			if ref_bill_to
				ref_customer = get_ref_row ref_bill_to, 'Corporation'
			end
			
			customer_id = "";
			if ref_customer
				customer_id = Field.value_by_field_name('Id', ref_customer)
			end
			
			date = Date.from_dmy(Field.value_by_field_name('IssueDate', @revision_row))
			
			corporation_id =""
			corporation_id = revision_row.value_by_field('Corporation Id')
			
			#      Check zero for show Rev No.
			if String(revision_row.rev_no) == "0"
				quotation_id = Field.value_by_field_name('Code', @revision_row)
			else
				quotation_id = @revision_row.description
			end
			#			quotation_id = @revision_row.description  #=> FCQ-A-14001 Rev.0
			#     quotation_id = Field.value_by_field_name('Code', @revision_row) + "-" + Field.value_by_field_name('Id', ref_customer) + "  Rev." + String(@revision_row.rev_no)                          #=> FCQ-A-14001-TSE Rev.0
			#     quotation_id = String(Field.value_by_field_name('Code', @revision_row)).insert(6, String(Field.value_by_field_name('Id', ref_customer)) + "-") + " Rev." + String(@revision_row.rev_no)  #=> FCQ-A-TSE-14001 Rev.0
			#project_code = Field.value_by_field_name('ProjectCode', @revision_row) + "-" + Field.value_by_field_name('Id', ref_customer) #=> 14001-A-TSE
			project_code = Field.value_by_field_name('ProjectCode', @revision_row) + "-" + corporation_id
			valid_until = Field.value_by_field_name('Quotation Valid Until', @revision_row)
			prepare_by = Field.value_by_field_name('Prepare by', @revision_row)
			fields = [date.strftime("%B %-d, %Y"), quotation_id, customer_id, project_code, '0 1055 4815 575 9', valid_until, prepare_by]
			
			data_fields = {}
			itr_cursor = 685
			itr_x = 410
			cell_width = 100
			fields.each do |field|
				data_fields[{:at => [itr_x, itr_cursor], :width => cell_width, :align => :right}] = field
				itr_cursor -= 10
			end
			
			data_fields
		end
		
		def draw_quotation_detail_table(y = 525)
			#~head
			table "table head",
			:x => 15, :y => y,
			:width => 490, :height => 25,
			:col => 5, :row => 1,
			:cells_width => [35, 175, 160, 50, 70],
			:fill_color => "FF66CC"
			
			# unit price head
			table "unit price head",
			:x => 225,
			:y => y,
			:width => 160, :height => 12.5,
			:col => 1, :row => 1
			
			# unit price details
			table "unit price details",
			:x => 225,
			:y => y - 12.5,
			:width => 160, :height => 12.5,
			:col => 3, :row => 1,
      :cells_width => [54, 53, 53]


			#~ :cells_width => [80, 45, 35]

			
			#~inner
			table "inner details",
			:x => 15,
			:y => y -25,
			:width => 490, :height => y-25-285,
			:col => 7, :row => 1,
			:cells_width => [35, 175, 54, 53, 53, 50, 70]
			
			#~footer
			table "table footer head",
			:x => 332,
			:y => 285,
			:width => 103, :height => 40,
			:col => 1, :row => 3,
			:fill_color => "FF66CC"
			table "table footer details",
			:x => 435,
			:y => 285,
			:width => 70, :height => 40,
			:col => 1, :row => 3
			
			#~ Details Header format
			property_table = {:align => :center, :valign => :center, :style => :bold}
			property_table_footer = property_table.merge({:width => 130, :height => 13.3})
			line_height = 25
			
			data_fields = {	"No." 		=> property_table.merge({:at => [15, y] , :width => 35, :height => line_height}),
				"Description" 	=> property_table.merge({:at => [50, y] , :width => 175, :height => line_height}),
				"Unit Price" 	=> property_table.merge({:at => [225, y] , :width => 160, :height => line_height/2}),
				"List Price" 	=> property_table.merge({:at => [215, y-12.5] , :width => 80, :height => line_height/2}),
				"Discount" 	=> property_table.merge({:at => [285, y-12.5] , :width => 45, :height => line_height/2}),
				#"Net Price" 	=> property_table.merge({:at => [350, y-12.5] , :width => 35, :height => line_height/2}),
        "Net Price" 	=> property_table.merge({:at => [345, y-12.5] , :width => 35, :height => line_height/2}),
				"Q'ty" 		=> property_table.merge({:at => [385, y] , :width => 50, :height => line_height}),
				"AMOUNT" 		=> property_table.merge({:at => [435, y] , :width => 70, :height => line_height})
			}
			
			table_footer_text = {	"Sub Total"	=> property_table_footer.merge(:at => [305, 285]),
				"Discount "	=> property_table_footer.merge(:at => [305, 285-13.3]),
				"GRAND TOTAL"	=> property_table_footer.merge(:at => [305, 285-(13.3*2)])
			}
			
			data_fields.merge!(table_footer_text)
			data_fields.each do |info, options|
				pdf.text_box info, options
			end
		end
		
		def print_template()
			#~Draw Logo
			pdf.repeat(:all) do
				pdf.stroke do
					options = {:position => 15,
						:vposition => 15,
						:width => 285,
						:height => 75
					}
					pdf.image "#{RAILS_ROOT}/client/fct/app/models/report_templates/images/logo_address.png", options
				end
				
				
				
				#~Line for signature
				pdf.dash 2, :space => 1
				pdf.stroke_horizontal_line 310, 380, :at => 202
				pdf.stroke_horizontal_line 440, 510, :at => 202
				pdf.stroke_horizontal_line 350, 505, :at => 116
				pdf.dash 1, :space => 0
				
			end
			
			#~Page number
			options = {:at => [305, 715],
				:width => 200,
				:start_count_at => 1,
				:page_filter => :all,
				:align => :right,
				:size => 8
			}
			pdf.number_pages("Page <page> / <total>", options)
			
			
			#~ Print Table
			pdf.repeat(lambda { |pg| pg == 1 }) do
				draw_quotation_detail_table
			end
			pdf.repeat(lambda { |pg| pg > 1 }) do
				draw_quotation_detail_table(600)
			end
			
			
			#format text
			page_footer_text = {	"Authorized Signature" => {:at => [305, 190], :width => 80, :height => 10, :overflow => :shrink_to_fit, :align => :center, :style => :bold},
				"Person in Charge" => {:at => [435, 190], :width => 80, :height => 10, :overflow => :shrink_to_fit, :align => :center, :style => :bold},
				"For Customer:" => {:at => [305, 170], :width => 200, :style => :bold},
				"Please sign confirm and fax the quotation back to at 662-714-3058" => {:at => [305, 162], :width => 200, :size => 6, :overflow => :shrink_to_fit, :style => :italic},
				"(" + " "*80 + ")\nAuthorized Signature" => {:at => [350, 115], :width => 155, :height => 15, :leading => 0, :overflow => :shrink_to_fit, :style => :bold, :align => :center},
				"THANK YOU FOR YOUR BUSINESS!" => {:at => [15, 100], :width => 490, :overflow => :shrink_to_fit, :style => :bold, :align => :center}
			}
			
			page_revision_text = {	"Bill To:" => {:at => [15, 670], :style => :bold},
				"C.C.:" => {:at => [150, 670],:style => :bold},
				"Comments or special instructions:" => {:at => [15, 600], :style => :bold},
				"We are pleased to submit our quotation as follows ;" => {:at => [15, 535], :style => :bold}
			}
			
			page_header_text = {	"Quotation" => {:at => [305, 735], :width => 200, :size => 20,:align => :right, :style => :bold,:overflow => :shrink_to_fit},
				"DATE:" => {:at => [290, 685], :width => 130, :align => :right, :style => :bold},
				"Quotation ID:" => {:at => [290, 675], :width => 130, :align => :right, :style => :bold},
				"Customer ID:" => {:at => [290, 665], :width => 130, :align => :right, :style => :bold},
				"Project Code:" => {:at => [290, 655], :width => 130, :align => :right, :style => :bold},
				"Tax ID No.:" => {:at => [290, 645], :width => 130, :align => :right, :style => :bold},
				"Quotation valid until:" => {:at => [290, 635], :width => 130, :align => :right, :style => :italic},
				"Prepared by:" => {:at => [290, 625], :width => 130, :align => :right, :style => :italic},
			}
			
			print_to_pdf(page_header_text, :all)
			print_to_pdf(page_footer_text, :all)
			print_to_pdf(page_revision_text, [1])
		end
		
		def get_item_info()
			@amounts = Array.new
			#~ initial data field for information from database
			include_meta_data = {'No.' 	=> {:at =>  [15 + @table_padding, 0], :width => 35 - (@table_padding * 2), :align => :right, :overflow => :shrink_to_fit},
				'Description' 	=> {:at => [50  + @table_padding, 0], :width => 175 - (@table_padding * 2), :align => :left, :overflow => :truncate },
				'Qty' 		=> {:at => [385, 0], :width => 50, :align => :center, :overflow => :shrink_to_fit },
				'Unit' 		=> {:at => [385 + @table_padding, 0], :width => 50 - (@table_padding * 2), :align => :right, :overflow => :shrink_to_fit }
			}
			more_details = {'Description' => {:at => [50 + @table_padding, 0], :width => 175 - (@table_padding * 2), :align => :left, :overflow => :truncate}}
			data_fields = {	'No.' 		=> {:at =>  [15, 0], :width => 35, :align => :center, :overflow => :shrink_to_fit},
				'Description' 	=> {:at => [50 + @table_padding, 0], :width => 175 - (@table_padding * 2), :align => :left, :overflow => :truncate},
				'ListPrice' 	=> {:at => [224 + @table_padding, 0], :width => 55 - (@table_padding * 2), :align => :right, :overflow => :shrink_to_fit},
				'Discount' 	=> {:at => [277 + @table_padding, 0], :width => 55 - (@table_padding * 2), :align => :right, :overflow => :shrink_to_fit},
				'NetPrice' 	=> {:at => [320 + @table_padding, 0], :width => 65 - (@table_padding * 2), :align => :right, :overflow => :shrink_to_fit},
				'Qty' 		=> {:at => [385, 0], :width => 50, :align => :center, :overflow => :shrink_to_fit},
				'Unit' 		=> {:at => [385 + @table_padding, 0], :width => 50 - (@table_padding * 2), :align => :right, :overflow => :shrink_to_fit},
				'Amount' 		=> {:at => [435 + @table_padding, 0], :width => 70 - (@table_padding * 2), :align => :right, :overflow => :shrink_to_fit},
				'Include'		=> include_meta_data,
				'More Detail' => more_details
			}
			
			#~ get information and set property for each information
			item_index = 0
			items = @revision_row.detail_rows.map do |r|
				item = {}
				data_fields.keys.collect{|f_name|
				val = ""
				key = data_fields[f_name]
				
				case f_name
				when 'Amount'
					amount_value = Field.value_by_field_name(f_name, r).delete(',').to_f
					amounts[item_index] = amount_value
					val = number_with_precision(amount_value, :precision => 2, :separator => '.', :delimiter => ',')
				when 'NetPrice'
					val = number_with_precision(Field.value_by_field_name(f_name, r).delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
				when 'ListPrice'
					val = number_with_precision(Field.value_by_field_name(f_name, r).delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
				when 'Include'
					next if Field.value_by_field_name(f_name, r) == ""
					rows = (Field.value_by_field_name('Include', r).gsub("<br />", "\n")).split("\n")
					include = rows.map do |row|
						col = row.split(' ')
						include_item = { 	include_meta_data['No.'] => "#{item_index+1}.#{col[0]}",
							include_meta_data['Description'] => col[1..-3].join(" "),
							include_meta_data['Qty'] => col[-2],
							include_meta_data['Unit'] => col[-1]}
							include_item
						end
						val = include
						key = f_name
					when 'More Detail'
						next if Field.value_by_field_name(f_name, r) == ""
						rows = (Field.value_by_field_name('More Detail', r).gsub("<br />", "\n")).split("\n")
						detail = rows.map do |row|
							detail_item = { more_details['Description'] => row}
							detail_item
						end
						val = detail
						key = f_name
					when 'No.'
						val = item_index+1
					when 'Unit'
						val = Field.value_by_field_name(f_name, r)
					when 'Discount'

#						discount_value = Field.value_by_field_name('UnitDiscount', r).delete(',').to_f
              discount_percentage = Field.value_by_field_name('Percentage Discount', r).delete(',').to_f
              if discount_percentage != 0.0
                discount = discount_percentage
              else
                discount = Field.value_by_field_name('UnitDiscount', r).delete(',').to_f
              end

              discount_value = number_with_precision(discount, :precision => 2, :separator => '.', :delimiter => ',')
              discount_value << '%' if discount_percentage != 0.0
						val = number_with_precision(discount_value, :precision => 2, :separator => '.', :delimiter => ',')
					else
						val = Field.value_by_field_name(f_name, r)
					end
					
					item[key]  = val
				}
				item_index +=1
				item
			end
			items
		end
		
		def genarate_detail(items, details)
			padding = details[:padding] == nil ? 1 : details[:padding]
			font_size = details[:font_size] == nil ? 8 : details[:font_size]
			leadding = details[:leadding] == nil ? 0 : details[:leadding]
			default_table_start = details[:default_table_start] == nil ? 490 : details[:default_table_start]
			new_table_start = details[:new_table_start] == nil ? default_table_start : details[:new_table_start]
			table_end = details[:table_end] == nil ? 300 : details[:table_end]
			
			itr_cursor = default_table_start
			item_index = 0
			items.each do |item|
				include_items = nil
				more_details = nil
				if item["Include"] != nil
					include_items = item.delete("Include")
				end
				if item["More Detail"] != nil
					more_details = item.delete("More Detail")
				end
				itr_cursor = new_line(itr_cursor,:font_size => font_size, :leadding => leadding, :default_table_start => default_table_start, :new_table_start => new_table_start, :table_end => table_end)
				@subtotal += amounts[item_index]
				roll = pdf.transaction do
					itr_cursor = print_details(item, :itr_cursor => itr_cursor, :leadding => leadding, :font_size => font_size)
					pdf.rollback if itr_cursor < (table_end == nil ? 300 : table_end)
				end
				if roll == false
					@subtotal -= amounts[item_index]
					itr_cursor = new_line(itr_cursor,:font_size => font_size, :leadding => leadding, :default_table_start => default_table_start, :new_table_start => new_table_start, :table_end => table_end)
					@subtotal += amounts[item_index]
					itr_cursor = print_details(item, :itr_cursor => itr_cursor, :leadding => leadding, :font_size => font_size)
				end
				
				item_index += 1
				
				if more_details != nil
					more_details.each do |more_detail|
						itr_cursor = new_line(itr_cursor, :font_size => font_size, :leadding => leadding, :default_table_start => default_table_start, :new_table_start => new_table_start, :table_end => table_end)
						roll = pdf.transaction do
							itr_cursor = print_details(more_detail, :itr_cursor => itr_cursor, :leadding => leadding, :font_size => font_size)
							pdf.rollback if itr_cursor < (table_end == nil ? 300 : table_end)
						end
						if roll == false
							itr_cursor = new_line(itr_cursor, :font_size => font_size, :leadding => leadding, :default_table_start => default_table_start, :new_table_start => new_table_start, :table_end => table_end)
							itr_cursor = print_details(more_detail, :itr_cursor => itr_cursor, :leadding => leadding, :font_size => font_size)
						end
					end
				end
				
				if include_items != nil
					itr_cursor = new_line(itr_cursor, :font_size => font_size, :leadding => leadding, :default_table_start => default_table_start, :new_table_start => new_table_start, :table_end => table_end)
					pdf.text_box "Include", :at => [50+ padding, itr_cursor], :width => 175 - (padding*2), :height => font_size+leadding, :font_size => font_size-1, :style => :bold
					
					include_items.each do |include_item|
						itr_cursor = new_line(itr_cursor, :font_size => font_size, :leadding => leadding, :default_table_start => default_table_start, :new_table_start => new_table_start, :table_end => table_end)
						itr_cursor = print_details(include_item, :itr_cursor => itr_cursor, :leadding => leadding, :font_size => font_size)
					end
				end
				
			end
			print_subtotal
		end
		
		def print_details(item, setting)
			itr_cursor = setting[:itr_cursor] == nil ? pdf.cursor : setting[:itr_cursor]
			font_size = setting[:font_size] == nil ? 8 : setting[:font_size]
			leadding = setting[:leadding] == nil ? 1 : setting[:leadding]
			excess_text_box = {}
			item.each do |options, field|
				options[:at][1] = itr_cursor
				options[:size] = font_size
				options[:leading] = 2

        #Ball 20160615-14_19
        options[:height] = font_size *2
        #options[:height] = default_height

        
				excess_text =  pdf.text_box field.to_s, options

				if excess_text != ""
					options[:at][1] -= (font_size+leadding)
					excess_text_box[excess_text] = options
				end
			end
			
			while !excess_text_box.empty?
				excess_text_box.each do |excess_text, options|
					next_excess_text = pdf.text_box(excess_text, options)
					if next_excess_text != ""
						options[:at][1] -= (font_size+leadding)
						
						excess_text_box[next_excess_text] = options
					end
					excess_text_box.delete(excess_text)
					itr_cursor = options[:at][1]
				end
			end
			itr_cursor
		end
		
		def print_subtotal()
			currency_id = Field.value_by_field_name('CurrencyID', @revision_row)
			x = 435 + @table_padding
			y = 281
			width = 70 - (@table_padding*2)
			pdf.text_box "#{currency_id}", {:at => [x, y], :width => width, :height => @font_size, :align => :left}
			pdf.text_box "#{number_to_currency(@subtotal, :unit =>"")}", {:at => [x, y], :width => width, :height => @font_size, :align => :right}
			
#			@subtotal = 0
		end
		
		def new_line(itr_cursor,setting)
			item_index = 5
			font_size = setting[:font_size] == nil ? 8 : setting[:font_size]
			leadding = setting[:leadding] == nil ? 0 : setting[:leadding]
			default_table_start = setting[:default_table_start] == nil ? 490 : setting[:default_table_start]
			new_table_start = setting[:new_table_start] == nil ? 560 : setting[:new_table_start]
			table_end = setting[:table_end] == nil ? 300 : setting[:table_end]
			
      itr_cursor -= (font_size+leadding)

#      if setting[:overflow]== :truncate
#        itr_cursor -= new_table_start-table_end
#      end

			if itr_cursor < table_end
				print_subtotal
				pdf.start_new_page
				itr_cursor = new_table_start
			end
			itr_cursor
		end
		
	end
end


