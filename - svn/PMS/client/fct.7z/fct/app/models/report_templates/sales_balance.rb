require 'report_template'

module ReportTemplates
  class SalesBalance < ReportTemplate
    def doc_options
      {
        :top_margin => (line_height*2)+50,
        :bottom_margin => (line_height*1)+50
      }
    end

    def draw(options = {})
      @cpo_row_ids = options[:row]

      set_reference_rows

      pdf.font_size(7)

      balance_details
      
      header
      default_footer
    end

    private

    def line_height
      15
    end

    def set_reference_rows
      @rows = {
        :cpo => []
      }
      
      @rows[:cpo] = Row.find(@cpo_row_ids)
    end

    def header
      x, y = pdf.bounds.top_left

      mark_0 = x
      y += doc_options[:top_margin] - 50

      pdf.repeat(:all) do
        #~ Title
        pdf.text_box "SALES BALANCE", :style => :bold,        :at => [mark_0, y]

        #~ Table Group Header
        x = mark_0
        y -= line_height
        header_groups = balance_data(:header_groups)

        header_groups.each{|h|
          unless h[:content].empty?
            pdf.bounding_box [x, y], :width => h[:column_width], :height => line_height do
              org_fill_color = pdf.fill_color
              pdf.fill_color(default_header_background_color)
              pdf.fill_rectangle pdf.bounds.top_left, pdf.bounds.width, pdf.bounds.height
              pdf.fill_color(org_fill_color)
              
              pdf.stroke_bounds
              pdf.text_box h[:content], :style => :bold, :align => h[:align], :valign => :center,
                :width => h[:column_width]
            end
          end
          x += h[:column_width]
        }
      end
    end

    def balance_details
      data = []
      data << balance_data(:headers)
      data += balance_data(:datas)
      pdf.table(data,
        :header => true,
        :column_widths => balance_data(:column_widths),
        :cell_style => { :padding => 2 }
      ) do |t|
        t.row(0).background_color = default_header_background_color
      end
    end

    def balance_data(item)
      @balance_data ||= begin
        settings = [
          { :group => '',         :header => 'Item No.',        :align => :center, :column_width => 30 },
          { :group => 'Quotation',      :header => 'Quotaion Code',  :align => :center, :column_width => 50 },
          { :group => 'Quotation',      :header => 'No. (Customer)',  :align => :center, :column_width => 50 },
          { :group => 'Quotation',      :header => 'Project Code',    :align => :center, :column_width => 65 },
          { :group => 'Quotation',      :header => 'Currency',        :align => :center, :column_width => 40 },
          { :group => 'Quotation',      :header => 'Amount',          :align => :right , :column_width => 60, :number_option => number_options },
          { :group => 'Quotation',      :header => 'Balance',         :align => :right , :column_width => 60, :number_option => number_options },
          { :group => 'Invoice',  :header => 'Date',            :align => :center, :column_width => 45 },
          { :group => 'Invoice',  :header => 'No.',             :align => :center, :column_width => 60 },
          { :group => 'Invoice',  :header => 'Amount',          :align => :right , :column_width => 60, :number_option => number_options }
        ]

        datas = balance_detail_datas(settings)

        header_groups = []
        settings.each do |s|
          header_group = header_groups.select{|hg| hg[:content] == s[:group] }.first
          if header_group
            header_group[:column_width] += s[:column_width]
          else
            header_groups << {:content => s[:group], :align => :center, :column_width => s[:column_width]}
          end
        end

        {
          :headers => settings.collect{|s| {:content => s[:header], :align => :center} },
          :datas => datas,
          :column_widths => settings.collect{|s| s[:column_width] },
          :header_groups => header_groups
        }
      end
      
      @balance_data[item]
    end

    def balance_detail_datas(settings)
      aligns = settings.collect{|s| s[:align] }
      number_options = settings.collect{|s| s[:number_option] }
      datas = []

      rows = []

      # Match invoice with cpo
      @rows[:cpo].each do |r|
        if r.value_by_field('C P/O').empty?
          next r
        end
        ref_rows = r.used_by(true)
        
        if ref_rows.any?{|ref| ref.screen.name =~ /Invoice/i }
          rows += ref_rows.collect{|ref|
            if ref.screen.name =~ /Invoice/i
              { :custom_order => r, :invoice => ref }
            end
          }.compact
        else
          rows << { :custom_order => r, :invoice => nil }
        end
      end

      rows.each_with_index do |r, idx|
        custom_order_row = r[:custom_order]
        invoice_row = r[:invoice]

        if custom_order_row
          quotation_code = custom_order_row.value_by_field('Code')
          po_no = custom_order_row.value_by_field('C P/O')
          project_code = custom_order_row.value_by_field('ProjectCode')
          po_amount = validate_value(custom_order_row.value_by_field('Subtotal')).to_f
          currency = custom_order_row.value_by_field('CurrencyID')
        end

        if invoice_row
          invoice_no = invoice_row.value_by_field('Invoice No')
          invoice_date = invoice_row.value_by_field('Date')
          invoice_amount = validate_value(invoice_row.value_by_field('Sub Total')).to_f
          currency = custom_order_row.value_by_field('CurrencyID') if currency.to_s.empty?
        end

        data = []
        data << 0
        data << quotation_code.to_s
        data << po_no.to_s
        data << project_code.to_s
        data << currency.to_s
        data << po_amount.to_f
        data << 0
        data << invoice_date.to_s
        data << invoice_no.to_s
        data << invoice_amount.to_f

        data.each_with_index{|d, idx|
          data[idx] = {
            :content => number_options[idx] ? number_with_precision(d, number_options[idx]).to_s : d.to_s,
            :align => aligns[idx]
          }
        }

        datas << data
      end

      datas = datas.sort_by{|d|
        dt6 = Date.from_dmy(d[6][:content])
        [
          d[1][:content],
          dt6,
          d[7][:content]
        ]
      }.each_with_index{|d, idx|
        d[0] = {:content => (idx + 1).to_s, :align => aligns[0] }
      }

      po_balance = 0
      last_po_no = ''
      datas.each{|d|
        if last_po_no != d[1][:content]
          last_po_no = d[1][:content]
          po_balance = validate_value(d[4][:content]).to_f   # po_amount
        else
          (1..4).each{|i| d[i][:content] = '' }
        end
        po_balance -= validate_value(d[8][:content]).to_f    # invoice_amount
        d[5][:content] = number_with_precision(po_balance, number_options[5])
      }

      datas
    end
  end
end
