require 'report_template'

module ReportTemplates
  class PurchaseOrder < ReportTemplate
    def draw(options = {})
      revision_row = options[:row]
      color_table = "ff66cc"
      pdf.font_size 8
      x = 15
      min_font = 6
      cal_sub_total = 0.0
      #~ Fields
      detail_field_names = [
        'Description',
        'UnitPrice',
        'Qty',
        'Discount',
        'Amount',
        'Unit',
        'Include',
        'More Detail',
        'DiscountPerAmount'
      ]
      get_field_value(revision_row)
      get_ref_info(revision_row)
      
      #~ repeat all page
      pdf.repeat(:all) do
        #~ Page Header
        page_header
        #~ Page Footer
        page_footer(x, color_table, min_font)
      end

      #~ report header
      #~ customer_contact
      customer_contact(x)
      #~ po detail
      po_detail(min_font)

      #~ Details
      #~ table of first page
      create_table(x, 595, 410, color_table)
      #~ table of next page
      pdf.repeat(lambda { |pg| pg > 1 }) do
        create_table(x, 660, 475, color_table)
      end
      #~ data
      pdf.bounding_box([x,630], :width => 500, :height => 485) do
        pdf.move_down 65
        item = Hash.new
        
        item['Description'] = Field.value_by_field_name('Subject for description', revision_row).gsub("<br />", "\n")
        data_table(nil, item, pdf.cursor, nil)

        no = 1.to_i
        screen_id_po_detail = 1064
        revision_row.detail_rows.each do |r|
          if r.screen_id == screen_id_po_detail
          detail_field_names.each { |f_name|
            if f_name == 'UnitPrice' || f_name == 'Amount'
              item[f_name.to_s] = number_with_precision(Field.value_by_field_name(f_name, r).delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
            elsif f_name == 'Discount' || f_name == 'DiscountPerAmount'
              discount = Field.value_by_field_name('Discount', r).delete(',').to_f
              discount_percentage = Field.value_by_field_name('Percentage Discount', r).delete(',').to_f
              
              if discount_percentage != 0.0
                discount = discount_percentage
              end
              
              item['Discount'] = number_with_precision(discount, :precision => 2, :separator => '.', :delimiter => ',')
              item['Discount'] << '%' if discount_percentage != 0.0
            else
              item[f_name.to_s] = Field.value_by_field_name(f_name, r)
            end
          }         
          cal_sub_total = data_table(no, item, pdf.cursor, cal_sub_total)
          no = no + 1
          end
        end      
      end
      
      #~ Sub Total, Vat and Grand Total, last page
      pdf.text_box number_with_precision(cal_sub_total, number_options), :align => :right, :at => [441,175], :width => 72
      if @field_value[:currency_id] == "THB"
        pdf.text_box @field_value[:currency_id], :at => [422,156], :width => 19
        pdf.text_box @field_value[:vat], :align => :right, :at => [441,156], :width => 72
      end
      pdf.text_box @field_value[:currency_id], :at => [422,138], :width => 19, :style => :bold
      pdf.text_box @field_value[:grand_total], :align => :right, :style => :bold, :at => [441,138], :width => 72

      #~ page number
      page_number
    end

    private

    def get_ref_row(row, field_name)
			field = row.screen.fields.select {|f| f.name == field_name }.first
			actual_row = Field.row_by_field(field, row)
			cell = actual_row.cell(field.custom_field_id) unless actual_row.nil?
			cell.absolute_value[:row] if cell
    end

    def get_field_value(revision_row)
      @field_value = {
        :po_no => "",
        :project_code => "",
        :date => "",
        :your_ref => "",
        :authorized_person => "",
        :in_charge_person => "",
		:authorized_person_sign => "",
        :in_charge_person_sign => "",
        :delivery_time => "",
        :shipping_condition => "",
       # :cust_ref => "",
        :part_maker => "",
        :currency_id => "",
        :vat => "",
        :grand_total => ""
      }

        ref_attendant = get_ref_row revision_row, 'Attendant'
      if ref_attendant
        ref_corporation = get_ref_row ref_attendant, 'Corporation'
      end
	  
	  ref_authorized_sign = ''
		ref_person_in_charge_sign = ''
		
	  ref_authorized = get_ref_row revision_row, 'Authorized Person'
    ref_substituted_by = get_ref_row revision_row, 'Substituted By'
		ref_person_in_charge = get_ref_row revision_row, 'In Charge Person'
		
		if ref_authorized
      if ref_substituted_by
          ref_authorized_sign = Field.value_by_field_name('SignatureFor', ref_substituted_by).gsub(/.*src=\"(.*?)\".*/, '\1')
        else
          ref_authorized_sign = Field.value_by_field_name('Signature', ref_authorized).gsub(/.*src=\"(.*?)\".*/, '\1')
        end
		end
		
		if ref_person_in_charge
			ref_person_in_charge_sign = Field.value_by_field_name('Signature', ref_person_in_charge).gsub(/.*src=\"(.*?)\".*/, '\1')
		end
			
	  corporation_id =""
	  corporation_id = revision_row.value_by_field('Corporation Id')

#      Check for show Rev No.
      if String(revision_row.rev_no) == "0"
        @field_value[:po_no] << Field.value_by_field_name('Code', revision_row)
      else
        @field_value[:po_no] << revision_row.description
      end
       #@field_value[:project_code] << Field.value_by_field_name('Project Code', revision_row) + "-" + Field.value_by_field_name('Id', ref_corporation)
	   @field_value[:project_code] << Field.value_by_field_name('Project Code', revision_row) + "-" + corporation_id	   
      date = Date.from_dmy(Field.value_by_field_name('Issue Date', revision_row))
      @field_value[:date] << date.strftime('%B %-d, %Y') if date != Date.null_date
      @field_value[:your_ref] << Field.value_by_field_name('Your Reference', revision_row)
      @field_value[:authorized_person] << Field.value_by_field_name('Authorized Person', revision_row)
	  @field_value[:authorized_person_sign] << ref_authorized_sign
      @field_value[:in_charge_person] << Field.value_by_field_name('In Charge Person', revision_row)
	  @field_value[:in_charge_person_sign] << ref_person_in_charge_sign
      delivery_time = Date.from_dmy(Field.value_by_field_name('Delivery Time', revision_row))
      @field_value[:delivery_time] << delivery_time.strftime('%-d/%-m/%Y') if delivery_time != Date.null_date
      @field_value[:shipping_condition] << Field.value_by_field_name('Shipping Condition', revision_row)
      #@field_value[:cust_ref] << Field.value_by_field_name('Cust. Ref', revision_row)
      @field_value[:part_maker] << Field.value_by_field_name('Part Maker', revision_row)
      @field_value[:currency_id] << Field.value_by_field_name('CurrencyID', revision_row)
      vat = number_with_precision(Field.value_by_field_name('Vat', revision_row).delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
      @field_value[:vat] << vat
      grand_total = number_with_precision(Field.value_by_field_name('Grand Total', revision_row).delete(',').to_f, :precision => 2, :separator => '.', :delimiter => ',')
      @field_value[:grand_total] << grand_total
    end

    def get_ref_info(revision_row)
      #~ Get the contact row
      contact_row = get_ref_row(revision_row, 'Attendant')
      if contact_row
        #~ Get the contact person's information
        @contact_info = {
          :title => "",
          :name => "",
          :surname => ""
        }
        @contact_info[:title] << Field.value_by_field_name('Title', contact_row)
        @contact_info[:name] << Field.value_by_field_name('Name', contact_row)
        @contact_info[:surname] << Field.value_by_field_name('Surname', contact_row)
        #~ Get the Corporation row
        corporation_row = get_ref_row(contact_row, 'Corporation')
      end
      if corporation_row
        #~ Get the corporation's information
        @corporation_info = {
          :name => "",
          :phone => "",
          :fax => "",
          :address => "",
          :payment => ""
        }
        @corporation_info[:name] << Field.value_by_field_name('Name', corporation_row)
        @corporation_info[:phone] << Field.value_by_field_name('Phone', corporation_row)
        @corporation_info[:fax] << Field.value_by_field_name('Fax', corporation_row)
        @corporation_info[:address] << Field.value_by_field_name('Address', corporation_row).gsub('<br />', "\n")
        @corporation_info[:payment] << Field.value_by_field_name('Payment', corporation_row)
      end
    end

    def page_header()
      pdf.image "#{RAILS_ROOT}/client/fct/app/models/report_templates/images/logo_address.png", :width => 340, :height => 85, :at => [15, pdf.cursor]
      pdf.bounding_box([375,750], :width => 300, :height => 200) do
        pdf.text "Purchase", :size => 25, :style => :bold
        pdf.text "Order", :size => 25, :style => :bold
      end
      pdf.text_box "เลขที่", :at =>[345, 688], :width => 70, :height => 20, :style => :bold, :align => :right
      pdf.text_box "P/O No.", :at =>[345, 676], :width => 70, :height => 20, :style => :bold, :align => :right
      pdf.text_box @field_value[:po_no], :at =>[420, 685], :width => 95, :height => 20, :style => :bold, :align => :right
    end

    def customer_contact(x)
      y_bound = 680
      y_data = y_bound-10
      pdf.stroke do
        pdf.rounded_rectangle [x, y_bound], 320, 80, 10
      end
      pdf.float do
        pdf.bounding_box([x+5,y_data], :width => 40, :height => 60) do
          pdf.text "Attn."
          pdf.move_down 6
          pdf.text "ที่อยู่"
          pdf.move_down 2
          pdf.text "Address"
        end
      end
      pdf.bounding_box([75,y_data], :width => 250, :height => 60) do
        pdf.text @contact_info[:title] +" "+ @contact_info[:name] +" "+ @contact_info[:surname], :style => :bold
        pdf.move_down 10
        pdf.text_box @corporation_info[:name], :at => [0, pdf.cursor],:width => 250, :height =>8, :overflow => :shrink_to_fit, :style => :bold, :min_font_size => 6
        pdf.move_down 10
        pdf.text_box @corporation_info[:address], :at => [0, pdf.cursor],:width => 250, :height => 25, :overflow => :shrink_to_fit, :style => :bold, :min_font_size => 6
        pdf.move_down 25
        pdf.text_box "Tel. : " + @corporation_info[:phone], :at =>[0, pdf.cursor], :width => 100, :height => 8, :style => :bold
        pdf.text_box "Fax : " + @corporation_info[:fax], :at =>[105, pdf.cursor], :width => 100, :height => 8, :style => :bold
      end
    end

    def po_detail(min_font)
      #y_bound = 660
	  y_bound = 660
      pdf.float do
        pdf.bounding_box([345,y_bound], :width => 70, :height => 80) do
		  pdf.text "Project Code.", :style => :bold, :align => :right
		  pdf.move_down 5
          pdf.text "วันที่", :style => :bold, :align => :right
          pdf.text "Date", :style => :bold, :align => :right
          pdf.move_down 5
          #pdf.text "Your Ref:", :style => :bold, :align => :right
		  @field_value[:your_ref].split(/ +/).each do |x|			
			pdf.text "Your Ref:", :style => :bold, :align => :right
			#pdf.move_down 10
			
		end
		#pdf.move_down 10
        end
      end
      pdf.bounding_box([420,y_bound], :width => 95, :height => 60) do
        pdf.text @field_value[:project_code], :align => :right
        pdf.move_down 3
        pdf.text "\n"+ @field_value[:date], :align => :right
        pdf.move_down 7
        #pdf.text_box @field_value[:your_ref], :at => [2,pdf.cursor], :width => 95, :height => 10, :align => :right, :overflow => :shrink_to_fit, :min_font_size => min_font
		
		@field_value[:your_ref].split(/ +/).each do |x|
		     pdf.text_box x, :at => [2,pdf.cursor], :width => 95, :height => 10, :align => :right, :overflow => :shrink_to_fit, :min_font_size => min_font
			 pdf.move_down 10
		end
		
		
      end
    end

    def create_table(x, detail_y, detail_height, color_table)
      w = 500
      x1 = 0
      x2 = 45
      x3 = 250
      x4 = 300
      x5 = 360
      x6 = 405
      w1 = x2
      w2 = x3 - x2
      w3 = x4 - x3
      w4 = x5 - x4
      w5 = x6 - x5
      w6 = w - x6
      pdf.save_graphics_state do
        pdf.fill_color color_table
        pdf.fill_and_stroke_rectangle [x,detail_y], w, 30
      end
      pdf.bounding_box([x,detail_y], :width => w, :height => detail_height) do
        pdf.stroke_bounds
        pdf.stroke do
          pdf.vertical_line 0, detail_height, :at => x2
          pdf.vertical_line 0, detail_height, :at => x3
          pdf.vertical_line 0, detail_height, :at => x4
          pdf.vertical_line 0, detail_height, :at => x5
          pdf.vertical_line 0, detail_height, :at => x6
        end
        pdf.move_down 3
        pdf.text_box "ลำดับ", :at => [x1,pdf.cursor], :align => :center, :width => w1, :style => :bold
        pdf.text_box "รายการ", :at => [x2,pdf.cursor], :align => :center, :width => w2, :style => :bold
        pdf.text_box "ราคาหน่วยละ", :at => [x3,pdf.cursor], :align => :center, :width => w3, :style => :bold
        pdf.text_box "จำนวน", :at => [x4,pdf.cursor], :align => :center, :width => w4, :style => :bold
        pdf.text_box "ส่วนลด", :at => [x5,pdf.cursor], :align => :center, :width => w5, :style => :bold
        pdf.text_box "รวมเป็นเงิน", :at => [x6,pdf.cursor], :align => :center, :width => w6, :style => :bold
        pdf.move_down 15
        pdf.text_box "No.", :at => [x1,pdf.cursor], :align => :center, :width => w1, :style => :bold
        pdf.text_box "Description", :at => [x2,pdf.cursor], :align => :center, :width => w2, :style => :bold
        pdf.text_box "Unit Price", :at => [x3,pdf.cursor], :align => :center, :width => w3, :style => :bold
        pdf.text_box "Q'ty", :at => [x4,pdf.cursor], :align => :center, :width => w4, :style => :bold
        pdf.text_box "Discount", :at => [x5,pdf.cursor], :align => :center, :width => w5, :style => :bold
        pdf.text_box "Amount", :at => [x6,pdf.cursor], :align => :center, :width => w6, :style => :bold
      end
    end

    def data_table(no, item, cursor, cal_sub_total)
      cursor, cal_sub_total = new_page(cal_sub_total) if cursor.to_i < 70
      x_desc = 47
      pdf.move_cursor_to cursor - 10
      coor_y = pdf.cursor
      pdf.text_box no.to_s, :at => [0, coor_y], :width => 45, :align => :center unless no.nil?
      pdf.text_box item['UnitPrice'], :at => [252, coor_y],:width => 46, :align => :right unless item['UnitPrice'].nil?
      pdf.text_box item['Qty'], :at => [302, coor_y],:width => 33, :align => :right unless item['Qty'].nil?
      pdf.text_box  item['Unit'], :at => [338, coor_y],:width => 20, :height => 20, :overflow => :shrink_to_fit unless item['Qty'].nil?
      pdf.text_box item['Discount'], :at => [362, coor_y],:width => 41, :align => :right unless item['Discount'].nil?
      pdf.text_box item['Amount'], :at => [407, coor_y],:width => 91, :align => :right unless item['Amount'].nil?
      cal_sub_total += item['Amount'].gsub(",","").to_f  unless item['Amount'].nil?
      pdf.move_cursor_to print_descr(x_desc, coor_y, item['Description']) unless item['Description'].nil?

      unless item['More Detail'].to_s.empty?
        detail = item['More Detail'].gsub('<br />', "\n")
        detail.each_line{|d|
          co_y = pdf.cursor
          if co_y.to_i < 70
            co_y, cal_sub_total = new_page(cal_sub_total)
            pdf.move_cursor_to co_y - 10
            co_y = pdf.cursor
          end
          roll = pdf.transaction do
            pdf.move_cursor_to print_descr(x_desc, co_y, d)
            pdf.rollback if pdf.cursor.to_i < 70
          end
          if roll == false
            co_y, cal_sub_total = new_page(cal_sub_total)
            pdf.move_cursor_to co_y - 10
            pdf.move_cursor_to print_descr(x_desc, pdf.cursor, d)
          end
        }
      end

      unless item['Include'].to_s.empty?
        co_y, cal_sub_total = new_page(cal_sub_total) if pdf.cursor.to_i < 70
        pdf.text_box 'Include', :at => [x_desc, pdf.cursor ]
        pdf.move_down 12
        include = item['Include'].gsub('<br />', "\n")
        inc_no = 1
        include.each_line{|i|
          co_y = pdf.cursor
          if co_y.to_i < 70
            co_y, cal_sub_total = new_page(cal_sub_total)
            pdf.move_cursor_to co_y - 10
            co_y = pdf.cursor
          end
          parti = i.partition(" ")
          if parti[0].empty? || parti[2].empty?
            pdf.text_box no.to_s + "." + inc_no.to_s, :at => [0, co_y], :width => 42, :align => :right
            pdf.move_cursor_to print_descr(x_desc, co_y, i)
            inc_no += 1
          else
            pdf.text_box no.to_s + "." + parti[0], :at => [0, co_y], :width => 42, :align => :right
            qty_unit = parti[2].split.last(3)
            if (qty_unit[2].nil? || qty_unit[1].nil? || qty_unit[0].nil?)
              pdf.move_cursor_to print_descr(x_desc, co_y, parti[2])
            else
              descr = parti[2].gsub(" "+ qty_unit[1] +" "+ qty_unit[2], "")
              pdf.text_box qty_unit[1], :at => [302, co_y],:width => 33, :align => :right
              pdf.text_box unit_pluralize(qty_unit[1], qty_unit[2]), :at => [338, co_y],:width => 20, :height => 20, :overflow => :shrink_to_fit
              pdf.move_cursor_to print_descr(x_desc, co_y, descr)
            end
          end
        }
      end

      cal_sub_total
    end
    
    def print_descr(x, y, description)
      pdf.bounding_box([x, y], :width => 201) do
        pdf.text(description, :leading => 5)
      end
      return pdf.cursor
    end

    #~ new page
    def new_page(cal_sub_total)
      pdf.text_box number_with_precision(cal_sub_total, number_options), :align => :right, :at => [426,30], :width => 72
      cal_sub_total = 0.0
      pdf.start_new_page
      pdf.move_cursor_to 485
      return pdf.cursor, cal_sub_total
    end

    def page_footer(x, color_table, min_font)
      y = 182
      pdf.stroke do
        pdf.line [x,y], [515,y]
        pdf.save_graphics_state do
          pdf.fill_color color_table
          pdf.fill_and_stroke_rectangle [265, y], 155, 57
        end
        pdf.line [515,125], [515,y]
        pdf.line [420,125], [515,125]
        pdf.line [265,55], [375,55]
        pdf.line [420,55], [515,55]
        pdf.rounded_rectangle [x, 70], 195, 60, 10
      end
      pdf.float do
        pdf.bounding_box([x,y], :width => 265, :height => 182) do
          pdf.move_down 7
          pdf.text "Terms and Conditions", :style => :bold
          pdf.stroke_horizontal_line 0, 76, :at => pdf.cursor+2
          pdf.move_down 10
          pdf.text "Payment Terms: " + @corporation_info[:payment]
          pdf.move_down 10
          pdf.text "Delivery Time: " + @field_value[:delivery_time]
          pdf.move_down 10
          pdf.text "Shipping Condition: " + @field_value[:shipping_condition]
          pdf.move_down 10
          pdf.text "Part Maker: " + @field_value[:part_maker]
          pdf.move_down 10
         # pdf.text "Cust. Ref: " + @field_value[:cust_ref]
        end
      end
      pdf.bounding_box([265,y], :width => 155, :height => 57) do
        pdf.text_box "รวม", :at => [52,54]
        pdf.text_box "/ Sub Total", :at => [66,50]
        pdf.text_box "ภาษีมูลค่าเพิ่ม" , :at => [43,35]
        pdf.text_box "/ Vat 7 %", :at => [83,31]
        pdf.text_box "จำนวนเงินรวมทั้งสิ้น", :at => [27,18], :style => :bold
        pdf.text_box "/ Grand Total", :at => [87,14], :style => :bold
      end
      pdf.float do
        pdf.bounding_box([25,70], :width => 175, :height => 60) do
          pdf.move_down 5
          pdf.text "Please sign confirm and fax this Purchase\nOrder back to at 662-714-3058", :align => :center
          pdf.move_down 10
          pdf.text "Signed................................Date....../....../......\nConfirmed delivery.........../.........../...........", :align => :center
        end
      end
      
	  
	  filename_temp = "#{RAILS_ROOT}/public#{@field_value[:authorized_person_sign]}"
	  if File.file?(filename_temp)
		#pdf.image filename_temp, :at => [240,70], :align => :center, :width => 160, :height => 10, :overflow => :shrink_to_fit, :min_font_size => min_font
		pdf.image filename_temp, :at => [270,85], :align => :center, :width => 100
	end
	  
	  filename_temp = "#{RAILS_ROOT}/public#{ @field_value[:in_charge_person_sign]}"
	  if File.file?(filename_temp)
		pdf.image filename_temp, :at => [415,85], :align => :center, :width => 100
	end
	  
		authorized_person = @field_value[:authorized_person].length>0? @field_value[:authorized_person]: " "*("Authorized Signature".length+20)
      #pdf.text_box "("+ @field_value[:authorized_person] +")", :at => [240,40], :align => :center, :width => 160, :height => 10, :overflow => :shrink_to_fit, :min_font_size => min_font
	  pdf.text_box "("+ authorized_person +")", :at => [240,40], :align => :center, :width => 160, :height => 10, :overflow => :shrink_to_fit, :min_font_size => min_font
      pdf.text_box "Authorized Signature", :at => [295,20], :size => 6
	  
	  in_charge_person = @field_value[:in_charge_person].length>0? @field_value[:in_charge_person]: " "*("Authorized Signature".length+20)
	  #in_charge_person = @field_value[:in_charge_person]? @field_value[:in_charge_person]
	  pdf.text_box "("+ in_charge_person +")", :at => [415,40], :align => :center, :width => 105, :height => 10, :overflow => :shrink_to_fit, :min_font_size => min_font
	  #pdf.text_box "("+ @field_value[:in_charge_person] +")", :at => [415,40], :align => :center, :width => 105, :height => 10, :overflow => :shrink_to_fit, :min_font_size => min_font
      pdf.text_box "Incharge Person", :at => [450,20], :size => 6
      pdf.text_box @field_value[:currency_id], :at => [422,175], :width => 19
    end

    def page_number
      str_page = "P.<page> of <total>"
      options = { :at => [450,713],
        :width => 50,
        :style => :bold,
        :align => :left,
        :page_filter => :all,
        :start_count_at => 1}
      pdf.number_pages str_page, options
    end

    def unit_pluralize(qty, unit)
      if qty.to_f != 1
        unit, d = unit.gsub(/(\.)$/, '|\1').split('|')
        "#{unit.to_s.pluralize}#{d}"
      else
        unit.to_s
      end
    end

  end
end
