# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20110513074217) do

  create_table "captions", :force => true do |t|
    t.integer  "label_id",    :limit => 4
    t.integer  "language_id", :limit => 4
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "captions", ["label_id", "language_id"], :name => "IX_captions_label_id_language_id"
  add_index "captions", ["label_id"], :name => "IX_captions_label_id"
  add_index "captions", ["language_id"], :name => "IX_captions_language_id"

  create_table "cells", :force => true do |t|
    t.integer  "row_id",     :limit => 4
    t.integer  "field_id",   :limit => 4
    t.yaml     "value"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "cells", ["field_id"], :name => "IX_cells_field_id"
  add_index "cells", ["row_id", "field_id"], :name => "IX_cells_row_id_field_id"
  add_index "cells", ["row_id"], :name => "IX_cells_row_id"

  create_table "custom_fields", :force => true do |t|
    t.string   "name"
    t.integer  "custom_field_id", :limit => 4
    t.string   "descr"
    t.integer  "label_id",        :limit => 4
    t.datetime "created_at"
    t.datetime "updated_at"
    t.yaml     "value"
    t.string   "display_flags"
    t.string   "type",                         :default => "CustomField", :null => false
  end

  add_index "custom_fields", ["custom_field_id"], :name => "IX_custom_fields_custom_field_id"
  add_index "custom_fields", ["name"], :name => "IX_custom_fields_name"
  add_index "custom_fields", ["type"], :name => "IX_custom_fields_type"

  create_table "detail_screens", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "field_filters", :force => true do |t|
    t.integer  "report_request_id",      :limit => 4
    t.integer  "field_id",               :limit => 4
    t.yaml     "value"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "reference_screen_index", :limit => 4
  end

  add_index "field_filters", ["field_id"], :name => "IX_field_filters_field_id"
  add_index "field_filters", ["report_request_id"], :name => "IX_field_filters_report_request_id"

  create_table "field_report_filters", :force => true do |t|
    t.integer  "report_id",              :limit => 4
    t.integer  "field_id",               :limit => 4
    t.yaml     "value"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "reference_screen_index", :limit => 4
  end

  add_index "field_report_filters", ["field_id"], :name => "IX_field_report_filters_field_id"
  add_index "field_report_filters", ["report_id"], :name => "IX_field_report_filters_request_id"

  create_table "fields", :force => true do |t|
    t.integer  "screen_id",       :limit => 4
    t.integer  "custom_field_id", :limit => 4
    t.integer  "display_seq",     :limit => 4
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "mandatory_check", :limit => 4
    t.integer  "unique",          :limit => 4
    t.string   "display_flags"
    t.string   "type",                         :default => "Fields::Data", :null => false
    t.yaml     "value"
    t.integer  "label_id",        :limit => 4
    t.string   "name"
    t.integer  "field_id",        :limit => 4
  end

  add_index "fields", ["custom_field_id"], :name => "IX_fields_custom_field_id"
  add_index "fields", ["screen_id"], :name => "IX_fields_screen_id"
  add_index "fields", ["type"], :name => "IX_fields_type"

  create_table "fields_reports", :force => true do |t|
    t.integer  "field_id",               :limit => 4, :null => false
    t.integer  "report_id",              :limit => 4, :null => false
    t.integer  "seq_no",                 :limit => 4, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "summarize"
    t.string   "location"
    t.yaml     "field_format"
    t.integer  "reference_screen_index", :limit => 4
    t.integer  "chart_axis_index",       :limit => 4
    t.integer  "label_id",               :limit => 4
  end

  add_index "fields_reports", ["field_id"], :name => "IX_fields_reports_field_id"
  add_index "fields_reports", ["report_id"], :name => "IX_fields_reports_report_id"

  create_table "full_logs", :force => true do |t|
    t.integer  "row_id",     :limit => 4
    t.integer  "seq_no",     :limit => 4
    t.yaml     "action"
    t.string   "user"
    t.yaml     "value"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "header_screens", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "labels", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "labels", ["name"], :name => "IX_labels_name"

  create_table "languages", :force => true do |t|
    t.string   "name",       :limit => 50
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "languages", ["name"], :name => "IX_languages_name"

  create_table "list_rows", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "list_screens", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "menu_group_screens", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "permissions", :force => true do |t|
    t.integer  "role_id",    :limit => 4
    t.integer  "user_id",    :limit => 4
    t.integer  "screen_id",  :limit => 4
    t.integer  "field_id",   :limit => 4
    t.yaml     "actions"
    t.string   "type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "permissions", ["role_id", "field_id"], :name => "IX_permissions_role_id_field_id"
  add_index "permissions", ["role_id", "screen_id"], :name => "IX_permissions_role_id_screen_id"
  add_index "permissions", ["type"], :name => "IX_permissions_type"
  add_index "permissions", ["user_id", "field_id"], :name => "IX_permissions_user_id_field_id"
  add_index "permissions", ["user_id", "screen_id"], :name => "IX_permissions_user_id_screen_id"

  create_table "report_request_cells", :force => true do |t|
    t.integer  "report_request_row_id", :limit => 4
    t.integer  "report_request_col_id", :limit => 4
    t.yaml     "value"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "report_request_cells", ["report_request_col_id"], :name => "IX_report_request_cells_report_request_col_id"
  add_index "report_request_cells", ["report_request_row_id"], :name => "IX_report_request_cells_report_request_row_id"

  create_table "report_request_cols", :force => true do |t|
    t.integer  "report_request_col_id", :limit => 4
    t.integer  "source_id",             :limit => 4
    t.integer  "fields_report_id",      :limit => 4
    t.string   "type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "report_request_id",     :limit => 4
  end

  add_index "report_request_cols", ["fields_report_id"], :name => "IX_report_request_cols_fields_report_id"
  add_index "report_request_cols", ["report_request_col_id"], :name => "IX_report_request_cols_report_request_col_id"
  add_index "report_request_cols", ["source_id"], :name => "IX_report_request_cols_source_id"

  create_table "report_request_rows", :force => true do |t|
    t.integer  "report_request_row_id",  :limit => 4
    t.integer  "row_id",                 :limit => 4
    t.integer  "report_request_id",      :limit => 4
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "reference_screen_index", :limit => 4
  end

  add_index "report_request_rows", ["report_request_id"], :name => "IX_report_request_rows_report_request_id"
  add_index "report_request_rows", ["report_request_row_id"], :name => "IX_report_request_rows_report_request_row_id"
  add_index "report_request_rows", ["row_id"], :name => "IX_report_request_rows_row_id"

  create_table "report_requests", :force => true do |t|
    t.string   "name"
    t.integer  "report_id",              :limit => 4
    t.integer  "user_id",                :limit => 4
    t.string   "remark"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "refresh_interval_index", :limit => 4
    t.datetime "last_run_at"
  end

  create_table "reports", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "descr"
    t.yaml     "reference_screen_ids"
    t.yaml     "criterias"
    t.yaml     "reference_screen_alias"
    t.string   "remark"
  end

  add_index "reports", ["name"], :name => "IX_reports_name"

  create_table "roles", :force => true do |t|
    t.string   "name"
    t.string   "descr"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "roles", ["name"], :name => "IX_roles_name"

  create_table "roles_users", :id => false, :force => true do |t|
    t.integer  "role_id",    :limit => 4
    t.integer  "user_id",    :limit => 4
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "roles_users", ["role_id", "user_id"], :name => "IX_roles_users_role_id_user_id"

  create_table "rows", :force => true do |t|
    t.integer  "screen_id",   :limit => 4
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "remark"
    t.string   "type"
    t.boolean  "delete_flag"
    t.integer  "row_id",      :limit => 4
    t.yaml     "value"
  end

  add_index "rows", ["delete_flag"], :name => "IX_rows_delete_flag"
  add_index "rows", ["screen_id"], :name => "IX_rows_screen_id"
  add_index "rows", ["type"], :name => "IX_rows_row_type"

  create_table "rows_sessions", :id => false, :force => true do |t|
    t.integer  "session_id", :limit => 4
    t.integer  "row_id",     :limit => 4
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "rows_sessions", ["session_id", "row_id"], :name => "IX_rows_sessions_session_id_row_id"

  create_table "screens", :force => true do |t|
    t.string   "name"
    t.integer  "screen_id",     :limit => 4
    t.integer  "label_id",      :limit => 4
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "system",        :limit => 4
    t.integer  "display_seq",   :limit => 4
    t.string   "action"
    t.string   "controller"
    t.string   "type"
    t.integer  "alias_screen",  :limit => 4
    t.integer  "relate_screen", :limit => 4
    t.yaml     "value"
  end

  add_index "screens", ["action", "controller"], :name => "IX_screens_action_controller"
  add_index "screens", ["name"], :name => "IX_screens_name"
  add_index "screens", ["screen_id"], :name => "IX_screens_screen_id"
  add_index "screens", ["system"], :name => "IX_screens_system"
  add_index "screens", ["type"], :name => "IX_screens_type"

  create_table "sessions", :force => true do |t|
    t.string   "session_id", :null => false
    t.yaml     "data"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sessions", ["session_id"], :name => "IX_sessions_session_id"
  add_index "sessions", ["session_id"], :name => "index_sessions_on_session_id"
  add_index "sessions", ["updated_at"], :name => "index_sessions_on_updated_at"

  create_table "sysdiagrams", :primary_key => "diagram_id", :force => true do |t|
    t.string  "name",         :limit => 128, :null => false
    t.integer "principal_id", :limit => 4,   :null => false
    t.integer "version",      :limit => 4
    t.binary  "definition"
  end

  add_index "sysdiagrams", ["principal_id", "name"], :name => "UK_principal_name", :unique => true

  create_table "users", :force => true do |t|
    t.string  "login"
    t.string  "password"
    t.integer "per_page",      :limit => 4
    t.boolean "disabled_flag",              :default => false, :null => false
  end

  add_index "users", ["login"], :name => "IX_users_login"

end
